import { CustomerUser, DriverUser, FareConfig, LocationPoint, RideBooking, SubsidyConfig } from '../types';

export const INITIAL_LOCATIONS: LocationPoint[] = [
  // Bhubaneswar
  {
    name: 'Master Canteen (Railway Station)',
    address: 'Station Square, Kharvel Nagar, Bhubaneswar, Odisha',
    lat: 20.2648,
    lng: 85.8394,
    city: 'Bhubaneswar'
  },
  {
    name: 'Biju Patnaik International Airport (BBI)',
    address: 'Aerodrome Area, Bhubaneswar, Odisha 751020',
    lat: 20.2526,
    lng: 85.8178,
    city: 'Bhubaneswar'
  },
  {
    name: 'KIIT Square & Infocity',
    address: 'Patia, Chandaka Industrial Estate, Bhubaneswar, Odisha',
    lat: 20.3533,
    lng: 85.8189,
    city: 'Bhubaneswar'
  },
  {
    name: 'Jaydev Vihar & Pal Heights',
    address: 'Nandankanan Road, Jaydev Vihar, Bhubaneswar, Odisha',
    lat: 20.2974,
    lng: 85.8245,
    city: 'Bhubaneswar'
  },
  {
    name: 'Esplanade One Mall & Saheed Nagar',
    address: 'Rasulgarh - Cuttack Road, Rasulgarh, Bhubaneswar, Odisha',
    lat: 20.2970,
    lng: 85.8675,
    city: 'Bhubaneswar'
  },
  {
    name: 'Khandagiri & Udayagiri Caves',
    address: 'Khandagiri, Near NH16, Bhubaneswar, Odisha',
    lat: 20.2599,
    lng: 85.7876,
    city: 'Bhubaneswar'
  },
  {
    name: 'AIIMS Hospital Bhubaneswar',
    address: 'Sijua, Patrapada, Bhubaneswar, Odisha 751019',
    lat: 20.2312,
    lng: 85.7766,
    city: 'Bhubaneswar'
  },
  
  // Cuttack
  {
    name: 'Badambadi Bus Terminal',
    address: 'Badambadi, Cuttack, Odisha 753012',
    lat: 20.4578,
    lng: 85.8776,
    city: 'Cuttack'
  },
  {
    name: 'Cuttack Railway Station',
    address: 'College Square, Malgodown, Cuttack, Odisha',
    lat: 20.4678,
    lng: 85.8945,
    city: 'Cuttack'
  },
  {
    name: 'SCB Medical College & Hospital',
    address: 'Mangalabag, Cuttack, Odisha 753007',
    lat: 20.4789,
    lng: 85.8856,
    city: 'Cuttack'
  },
  {
    name: 'Barabati Stadium & Fort',
    address: 'Biju Patnaik Colony, Cuttack, Odisha 753001',
    lat: 20.4822,
    lng: 85.8687,
    city: 'Cuttack'
  },
  {
    name: 'CDA Sector 9 / High Court Area',
    address: 'Bidanasi, CDA Sector 9, Cuttack, Odisha',
    lat: 20.4905,
    lng: 85.8312,
    city: 'Cuttack'
  },
  {
    name: 'Link Road Junction',
    address: 'Madhupatna, Link Road, Cuttack, Odisha',
    lat: 20.4498,
    lng: 85.8834,
    city: 'Cuttack'
  }
];

export const INITIAL_DRIVERS: DriverUser[] = [
  // --- OWNER'S OWN THREE VEHICLES ---
  {
    id: 'drv-bike-01',
    name: 'Rakesh Sahoo',
    phone: '9861041234',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
    rating: 4.92,
    totalTrips: 310,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-02-BK-5521',
    vehicleCategory: 'bike',
    vehicleModel: 'Hero Splendor Plus (Helmet Provided)',
    vehicleOwnership: 'independent',
    drivingLicenseNo: 'OD02-2020-0081299',
    rcNumber: 'RC-OD02-BK-5521',
    insurancePolicyNo: 'NIA-OD-BK-9182',
    documentSubmittedDate: '2026-09-10',
    upiId: 'rakesh.sahoo@upi',
    bankAccountNo: 'SBIN00049281721',
    ifscCode: 'SBIN0002087',
    currentLocation: { lat: 20.2690, lng: 85.8340 }, // Near Master Canteen
    currentCity: 'Bhubaneswar'
  },
  {
    id: 'drv-bike-02',
    name: 'Deepak Mohanty',
    phone: '9861059876',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
    rating: 4.88,
    totalTrips: 185,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-05-BK-3319',
    vehicleCategory: 'bike',
    vehicleModel: 'Honda Shine 125 SP (Helmet Provided)',
    vehicleOwnership: 'independent',
    drivingLicenseNo: 'OD05-2021-0044912',
    rcNumber: 'RC-OD05-BK-3319',
    insurancePolicyNo: 'BAJAJ-OD-BK-3319',
    documentSubmittedDate: '2026-09-12',
    upiId: 'deepak.shine@upi',
    bankAccountNo: 'UTBI0009988221',
    ifscCode: 'PUNB0008800',
    currentLocation: { lat: 20.4590, lng: 85.8790 }, // Near Badambadi
    currentCity: 'Cuttack'
  },
  {
    id: 'drv-owner-01',
    name: 'Subrat Mohapatra',
    phone: '9861011111',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    rating: 4.9,
    totalTrips: 184,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-02-AX-1001',
    vehicleCategory: 'auto',
    vehicleModel: 'Bajaj RE Compact 4S Auto',
    vehicleOwnership: 'owner_company',
    ownerName: 'Odisha Ride Enterprise (Owner)',
    drivingLicenseNo: 'OD02-2018-0045231',
    rcNumber: 'RC-OD02-AX-1001',
    insurancePolicyNo: 'NIA-OD-8849201',
    documentSubmittedDate: '2026-09-15',
    upiId: 'subrat.or@upi',
    bankAccountNo: 'SBIN00010294821',
    ifscCode: 'SBIN0002087',
    currentLocation: { lat: 20.2670, lng: 85.8360 }, // Near Master Canteen
    currentCity: 'Bhubaneswar'
  },
  {
    id: 'drv-owner-02',
    name: 'Bikram Nayak',
    phone: '9861022222',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    rating: 4.85,
    totalTrips: 242,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-02-BD-2002',
    vehicleCategory: 'cab',
    vehicleModel: 'Maruti Suzuki Dzire Tour Sedan',
    vehicleOwnership: 'owner_company',
    ownerName: 'Odisha Ride Enterprise (Owner)',
    drivingLicenseNo: 'OD02-2016-0098411',
    rcNumber: 'RC-OD02-BD-2002',
    insurancePolicyNo: 'HDFC-OD-3391824',
    documentSubmittedDate: '2026-09-15',
    upiId: 'bikram.cab@upi',
    bankAccountNo: 'HDFC0001928374',
    ifscCode: 'HDFC0000341',
    currentLocation: { lat: 20.2580, lng: 85.8210 }, // Near Airport
    currentCity: 'Bhubaneswar'
  },
  {
    id: 'drv-owner-03',
    name: 'Pradeep Das',
    phone: '9861033333',
    photoUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=200&q=80',
    rating: 4.92,
    totalTrips: 198,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-02-CE-3003',
    vehicleCategory: 'cab',
    vehicleModel: 'Hyundai Aura S CNG',
    vehicleOwnership: 'owner_company',
    ownerName: 'Odisha Ride Enterprise (Owner)',
    drivingLicenseNo: 'OD02-2019-0012984',
    rcNumber: 'RC-OD02-CE-3003',
    insurancePolicyNo: 'ICICI-OD-4491029',
    documentSubmittedDate: '2026-09-18',
    upiId: 'pradeep.aura@upi',
    bankAccountNo: 'ICIC0000928374',
    ifscCode: 'ICIC0000045',
    currentLocation: { lat: 20.3510, lng: 85.8230 }, // Near Patia KIIT
    currentCity: 'Bhubaneswar'
  },

  // --- FRIENDS' VEHICLES ---
  {
    id: 'drv-friend-01',
    name: 'Rajesh Panda (Friend)',
    phone: '9861044444',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
    rating: 4.75,
    totalTrips: 112,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-05-FR-4004',
    vehicleCategory: 'auto',
    vehicleModel: 'Piaggio Ape City Smart Auto',
    vehicleOwnership: 'friend',
    ownerName: 'Debashish Panda (Owner Friend)',
    drivingLicenseNo: 'OD05-2020-0077123',
    rcNumber: 'RC-OD05-FR-4004',
    insurancePolicyNo: 'BAJAJ-OD-9928172',
    documentSubmittedDate: '2026-10-01',
    upiId: 'rajesh.panda@upi',
    bankAccountNo: 'UTBI0008827364',
    ifscCode: 'PUNB0008800',
    currentLocation: { lat: 20.4550, lng: 85.8750 }, // Badambadi Cuttack
    currentCity: 'Cuttack'
  },
  {
    id: 'drv-friend-02',
    name: 'Amit Tripathy (Friend)',
    phone: '9861055555',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    rating: 4.8,
    totalTrips: 145,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-05-FR-5005',
    vehicleCategory: 'cab',
    vehicleModel: 'Tata Tigor EV / Xpres-T',
    vehicleOwnership: 'friend',
    ownerName: 'Manas Tripathy (Owner Friend)',
    drivingLicenseNo: 'OD05-2017-0033491',
    rcNumber: 'RC-OD05-FR-5005',
    insurancePolicyNo: 'TATA-AIG-OD-8273',
    documentSubmittedDate: '2026-10-02',
    upiId: 'amit.tripathy@upi',
    bankAccountNo: 'AXIS0009988771',
    ifscCode: 'UTIB0000078',
    currentLocation: { lat: 20.4760, lng: 85.8820 }, // SCB Medical Cuttack
    currentCity: 'Cuttack'
  },

  // --- INDEPENDENT DRIVERS ---
  {
    id: 'drv-ind-01',
    name: 'Manoj Behera',
    phone: '9861066666',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
    rating: 4.88,
    totalTrips: 94,
    isOnline: true,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-02-IN-6006',
    vehicleCategory: 'auto',
    vehicleModel: 'Mahindra Alfa DX Auto',
    vehicleOwnership: 'independent',
    drivingLicenseNo: 'OD02-2021-0081293',
    rcNumber: 'RC-OD02-IN-6006',
    insurancePolicyNo: 'RELIANCE-OD-8812',
    documentSubmittedDate: '2026-10-10',
    upiId: 'manoj.behera@upi',
    bankAccountNo: 'BOI00012938472',
    ifscCode: 'BKID0005401',
    currentLocation: { lat: 20.2950, lng: 85.8280 }, // Jaydev Vihar
    currentCity: 'Bhubaneswar'
  },
  {
    id: 'drv-ind-02',
    name: 'Santosh Samal',
    phone: '9861077777',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
    rating: 4.65,
    totalTrips: 78,
    isOnline: false,
    isApproved: true,
    approvalStatus: 'approved',
    vehicleNumber: 'OD-05-IN-7007',
    vehicleCategory: 'cab',
    vehicleModel: 'Toyota Platinum Etios',
    vehicleOwnership: 'independent',
    drivingLicenseNo: 'OD05-2015-0049281',
    rcNumber: 'RC-OD05-IN-7007',
    insurancePolicyNo: 'CHOLA-OD-39182',
    documentSubmittedDate: '2026-10-12',
    upiId: 'santosh.samal@upi',
    bankAccountNo: 'CAN00099182736',
    ifscCode: 'CNRB0001092',
    currentLocation: { lat: 20.4850, lng: 85.8650 }, // Barabati Cuttack
    currentCity: 'Cuttack'
  },
  {
    id: 'drv-ind-03',
    name: 'Soumya Ranjan Rout',
    phone: '9861088888',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
    rating: 5.0,
    totalTrips: 0,
    isOnline: false,
    isApproved: false,
    approvalStatus: 'pending', // PENDING ADMIN APPROVAL
    vehicleNumber: 'OD-02-IN-8008',
    vehicleCategory: 'cab',
    vehicleModel: 'Honda Amaze VX Petrol',
    vehicleOwnership: 'independent',
    drivingLicenseNo: 'OD02-2023-0091824',
    rcNumber: 'RC-OD02-IN-8008',
    insurancePolicyNo: 'STAR-OD-9928172',
    documentSubmittedDate: '2026-11-04',
    upiId: 'soumya.rout@upi',
    bankAccountNo: 'KKBK0001928374',
    ifscCode: 'KKBK0000491',
    currentLocation: { lat: 20.2980, lng: 85.8650 }, // Rasulgarh
    currentCity: 'Bhubaneswar'
  }
];

export const INITIAL_CUSTOMER: CustomerUser = {
  id: 'cust-demo-01',
  name: 'Bapina Senapati',
  phone: '9861099887',
  email: 'bapinasenapati2@gmail.com',
  emergencyContact: '9437012345',
  rating: 4.95,
  savedPlaces: {
    home: INITIAL_LOCATIONS[0], // Master Canteen
    work: INITIAL_LOCATIONS[2], // KIIT Infocity
  }
};

export const DEFAULT_FARE_CONFIG: FareConfig = {
  bike: {
    baseFare: 20, // First 1.5 km
    perKmRate: 9,
    minFare: 20,
    platformFee: 5
  },
  auto: {
    baseFare: 30, // First 1.5 km
    perKmRate: 14,
    minFare: 30,
    platformFee: 7
  },
  cab: {
    baseFare: 60, // First 2.0 km
    perKmRate: 20,
    minFare: 60,
    platformFee: 10
  }
};

export const DEFAULT_SUBSIDY_CONFIG: SubsidyConfig = {
  isActive: true,
  percentage: 50, // 50% Odisha Customer Subsidy
  launchDate: '2026-10-01',
  validUntil: '2027-04-01', // 6 months from launch
  description: 'First 6 Months Special 50% Customer Subsidy (Customer pays 50%, Odisha Ride covers 50%, Driver receives full 100%)'
};

export const INITIAL_PAST_RIDES: RideBooking[] = [
  {
    id: 'ride-hist-101',
    bookingRef: 'OR-8472',
    customerId: 'cust-demo-01',
    customerName: 'Bapina Senapati',
    customerPhone: '9861099887',
    driverId: 'drv-owner-01',
    driverName: 'Subrat Mohapatra',
    driverPhone: '9861011111',
    driverRating: 4.9,
    vehicleNumber: 'OD-02-AX-1001',
    vehicleModel: 'Bajaj RE Auto',
    vehicleCategory: 'auto',
    vehicleOwnership: 'owner_company',
    pickup: INITIAL_LOCATIONS[0], // Master Canteen
    destination: INITIAL_LOCATIONS[3], // Jaydev Vihar
    status: 'completed',
    startOtp: '4192',
    distanceKm: 5.4,
    durationMins: 16,
    totalGrossFare: 106,
    subsidyPercentage: 50,
    companySubsidyAmount: 53,
    customerPayableFare: 53,
    driverPayoutAmount: 106,
    isCompanyVehicle: true,
    paymentMethod: 'upi_qr',
    paymentStatus: 'completed',
    transactionId: 'UPI-OR-20261102-8819',
    createdAt: '2026-11-02T09:30:00Z',
    acceptedAt: '2026-11-02T09:31:00Z',
    arrivedAt: '2026-11-02T09:34:00Z',
    startedAt: '2026-11-02T09:35:00Z',
    completedAt: '2026-11-02T09:51:00Z',
    ratingByCustomer: 5,
    reviewByCustomer: 'Great ride! Driver was courteous and punctual.'
  },
  {
    id: 'ride-hist-102',
    bookingRef: 'OR-8921',
    customerId: 'cust-demo-01',
    customerName: 'Bapina Senapati',
    customerPhone: '9861099887',
    driverId: 'drv-owner-02',
    driverName: 'Bikram Nayak',
    driverPhone: '9861022222',
    driverRating: 4.85,
    vehicleNumber: 'OD-02-BD-2002',
    vehicleModel: 'Maruti Dzire Sedan',
    vehicleCategory: 'cab',
    vehicleOwnership: 'owner_company',
    pickup: INITIAL_LOCATIONS[1], // Airport
    destination: INITIAL_LOCATIONS[2], // KIIT Patia
    status: 'completed',
    startOtp: '7721',
    distanceKm: 14.8,
    durationMins: 32,
    totalGrossFare: 316,
    subsidyPercentage: 50,
    companySubsidyAmount: 158,
    customerPayableFare: 158,
    driverPayoutAmount: 316,
    isCompanyVehicle: true,
    paymentMethod: 'online',
    paymentStatus: 'completed',
    transactionId: 'RZP-OR-99182374',
    createdAt: '2026-11-03T14:15:00Z',
    acceptedAt: '2026-11-03T14:16:00Z',
    arrivedAt: '2026-11-03T14:20:00Z',
    startedAt: '2026-11-03T14:21:00Z',
    completedAt: '2026-11-03T14:53:00Z',
    ratingByCustomer: 5,
    reviewByCustomer: 'AC was cool, smooth highway ride via Nandankanan road.'
  },
  {
    id: 'ride-hist-103',
    bookingRef: 'OR-9104',
    customerId: 'cust-demo-01',
    customerName: 'Bapina Senapati',
    customerPhone: '9861099887',
    driverId: 'drv-friend-01',
    driverName: 'Rajesh Panda',
    driverPhone: '9861044444',
    driverRating: 4.75,
    vehicleNumber: 'OD-05-FR-4004',
    vehicleModel: 'Piaggio Ape Auto',
    vehicleCategory: 'auto',
    vehicleOwnership: 'friend',
    pickup: INITIAL_LOCATIONS[7], // Badambadi Cuttack
    destination: INITIAL_LOCATIONS[9], // SCB Medical
    status: 'completed',
    startOtp: '3382',
    distanceKm: 3.8,
    durationMins: 14,
    totalGrossFare: 62,
    subsidyPercentage: 50,
    companySubsidyAmount: 31,
    customerPayableFare: 31,
    driverPayoutAmount: 62,
    isCompanyVehicle: false,
    paymentMethod: 'cash',
    paymentStatus: 'completed',
    createdAt: '2026-11-04T11:00:00Z',
    acceptedAt: '2026-11-04T11:01:00Z',
    arrivedAt: '2026-11-04T11:04:00Z',
    startedAt: '2026-11-04T11:05:00Z',
    completedAt: '2026-11-04T11:19:00Z',
    ratingByCustomer: 4
  },
  {
    id: 'ride-hist-104',
    bookingRef: 'OR-9450',
    customerId: 'cust-demo-01',
    customerName: 'Bapina Senapati',
    customerPhone: '9861099887',
    driverId: 'drv-bike-01',
    driverName: 'Rakesh Sahoo',
    driverPhone: '9861041234',
    driverRating: 4.92,
    vehicleNumber: 'OD-02-BK-5521',
    vehicleModel: 'Hero Splendor Plus',
    vehicleCategory: 'bike',
    vehicleOwnership: 'independent',
    pickup: INITIAL_LOCATIONS[0], // Master Canteen
    destination: INITIAL_LOCATIONS[4], // Esplanade Mall
    status: 'completed',
    startOtp: '5512',
    distanceKm: 4.2,
    durationMins: 9,
    baseFare: 20,
    distanceFare: 24,
    platformFee: 5,
    totalGrossFare: 49,
    subsidyPercentage: 50,
    companySubsidyAmount: 24.5,
    customerPayableFare: 24.5,
    driverPayoutAmount: 49,
    isCompanyVehicle: false,
    paymentMethod: 'upi_qr',
    paymentStatus: 'completed',
    transactionId: 'UPI-OR-20261105-4421',
    createdAt: '2026-11-05T08:30:00Z',
    acceptedAt: '2026-11-05T08:31:00Z',
    arrivedAt: '2026-11-05T08:33:00Z',
    startedAt: '2026-11-05T08:34:00Z',
    completedAt: '2026-11-05T08:43:00Z',
    ratingByCustomer: 5,
    reviewByCustomer: 'Fast, smooth bike taxi through Master Canteen traffic. Helmet provided!'
  }
];
