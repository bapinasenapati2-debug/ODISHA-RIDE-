export type Role = 'customer' | 'driver' | 'admin';

export type Language = 'en' | 'or' | 'hi'; // English, Odia, Hindi

export type VehicleCategory = 'auto' | 'cab' | 'bike';

export type VehicleOwnership = 'owner_company' | 'friend' | 'independent';

export type RideStatus = 
  | 'idle'
  | 'searching'
  | 'driver_assigned'
  | 'driver_arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type PaymentMethod = 'upi_qr' | 'online' | 'cash';
export type PaymentStatus = 'pending' | 'completed' | 'failed';

export interface LocationPoint {
  name: string;
  address: string;
  lat: number;
  lng: number;
  city: 'Bhubaneswar' | 'Cuttack';
}

export interface CustomerUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  emergencyContact: string;
  rating: number;
  isLoggedIn?: boolean;
  savedPlaces?: {
    home?: LocationPoint;
    work?: LocationPoint;
    other?: LocationPoint[];
  };
}

export interface DriverUser {
  id: string;
  name: string;
  phone: string;
  photoUrl: string;
  rating: number;
  totalTrips: number;
  isOnline: boolean;
  isApproved: boolean;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  
  // Vehicle details
  vehicleNumber: string; // e.g. OD-02-AX-1001
  vehicleCategory: VehicleCategory;
  vehicleModel: string; // e.g. "Bajaj Maxima Z", "Honda Shine", "Maruti Swift Dzire"
  vehicleOwnership: VehicleOwnership; // Owner's own, Friend, Independent
  ownerName?: string;
  
  // Documents
  drivingLicenseNo: string;
  rcNumber: string;
  insurancePolicyNo: string;
  documentSubmittedDate: string;
  
  // Bank / UPI Payout details
  upiId: string;
  bankAccountNo: string;
  ifscCode: string;

  // Real-time position
  currentLocation: {
    lat: number;
    lng: number;
  };
  currentCity: 'Bhubaneswar' | 'Cuttack';
}

export interface FareCalculation {
  distanceKm: number;
  durationMins: number;
  baseFare: number;
  distanceFare: number;
  platformFee: number;
  totalGrossFare: number;
  subsidyPercentage: number; // default 50%
  companySubsidyAmount: number; // 50% of total
  customerPayableFare: number; // 50% of total
  driverGrossEarnings: number; // 100% of total
  etaMins: number;
}

export interface RideBooking {
  id: string;
  bookingRef: string; // e.g. OR-8472
  customerId: string;
  customerName: string;
  customerPhone: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverPhotoUrl?: string;
  driverRating?: number;
  vehicleNumber?: string;
  vehicleModel?: string;
  vehicleCategory: VehicleCategory;
  vehicleOwnership?: VehicleOwnership;
  
  pickup: LocationPoint;
  destination: LocationPoint;
  
  status: RideStatus;
  startOtp: string; // 4 digit OTP for driver to start ride
  
  // Financial breakdown
  distanceKm: number;
  durationMins: number;
  baseFare?: number;
  distanceFare?: number;
  platformFee?: number;
  totalGrossFare: number;
  subsidyPercentage: number;
  companySubsidyAmount: number;
  customerPayableFare: number;
  driverPayoutAmount: number;
  isCompanyVehicle: boolean;
  
  // Payment
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  
  // Timestamps
  createdAt: string;
  acceptedAt?: string;
  arrivedAt?: string;
  startedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  
  // Rating & Review
  ratingByCustomer?: number;
  reviewByCustomer?: string;
}

export interface FareConfig {
  bike: {
    baseFare: number; // ₹20 for first 1.5 km
    perKmRate: number; // ₹9 / km
    minFare: number; // ₹20
    platformFee: number; // ₹5
  };
  auto: {
    baseFare: number; // ₹30 for first 1.5 km
    perKmRate: number; // ₹14 / km
    minFare: number; // ₹30
    platformFee: number; // ₹7
  };
  cab: {
    baseFare: number; // ₹60 for first 2 km
    perKmRate: number; // ₹20 / km
    minFare: number; // ₹60
    platformFee: number; // ₹10
  };
}

export interface SubsidyConfig {
  isActive: boolean;
  percentage: number; // 50% default
  launchDate: string; // e.g. 2026-10-01
  validUntil: string; // 6 months from launch
  description: string;
}

export interface SupportTicket {
  id: string;
  rideId?: string;
  userType: 'customer' | 'driver';
  userId: string;
  userName: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
}
