import { FareCalculation, FareConfig, LocationPoint, SubsidyConfig, VehicleCategory } from '../types';

/**
 * Calculates road distance in kilometers using the Haversine formula with a realistic road factor
 * (1.25x curvature for Indian urban roads).
 */
export function calculateDistanceKm(from: LocationPoint, to: LocationPoint): number {
  const R = 6371; // Earth radius in km
  const dLat = ((to.lat - from.lat) * Math.PI) / 180;
  const dLng = ((to.lng - from.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((from.lat * Math.PI) / 180) *
      Math.cos((to.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const straightLineDistance = R * c;

  // Road factor in Bhubaneswar & Cuttack urban grid (typically 1.25x to 1.35x straight line)
  const roadFactor = 1.28;
  const roadDistance = straightLineDistance * roadFactor;
  return Math.max(1.0, Math.round(roadDistance * 10) / 10);
}

/**
 * Estimated travel time in minutes based on urban traffic in Bhubaneswar / Cuttack
 * (Bike ~30 km/h; Auto ~22 km/h; Cab ~26 km/h)
 */
export function calculateDurationMins(distanceKm: number, category: VehicleCategory): number {
  const avgSpeedKmH = category === 'bike' ? 30 : category === 'auto' ? 22 : 26;
  const hours = distanceKm / avgSpeedKmH;
  const mins = Math.ceil(hours * 60) + 3; // traffic buffer
  return Math.max(4, mins);
}

/**
 * Estimated arrival time (ETA) for nearby driver in minutes
 */
export function calculateDriverEta(category: VehicleCategory): number {
  if (category === 'bike') return 2;
  if (category === 'auto') return 3;
  return 5;
}

/**
 * Calculates fare and 50% Odisha customer subsidy
 */
export function calculateFare(
  from: LocationPoint,
  to: LocationPoint,
  category: VehicleCategory,
  fareConfig: FareConfig,
  subsidyConfig: SubsidyConfig
): FareCalculation {
  const distanceKm = calculateDistanceKm(from, to);
  const durationMins = calculateDurationMins(distanceKm, category);
  const etaMins = calculateDriverEta(category);

  const config = fareConfig[category] || fareConfig.auto;
  const baseThresholdKm = category === 'bike' ? 1.0 : category === 'auto' ? 1.5 : 2.0;
  const platformFee = config.platformFee || (category === 'bike' ? 5 : category === 'auto' ? 7 : 10);

  let distanceFare = 0;
  if (distanceKm > baseThresholdKm) {
    distanceFare = Math.round((distanceKm - baseThresholdKm) * config.perKmRate);
  }

  const grossCalculated = config.baseFare + distanceFare + platformFee;
  const totalGrossFare = Math.max(config.minFare, grossCalculated);

  const subsidyPercentage = subsidyConfig.isActive ? subsidyConfig.percentage : 0;
  const companySubsidyAmount = Math.round((totalGrossFare * subsidyPercentage) / 100);
  const customerPayableFare = totalGrossFare - companySubsidyAmount;
  const driverGrossEarnings = totalGrossFare; // Driver ALWAYS gets 100% full approved fare!

  return {
    distanceKm,
    durationMins,
    baseFare: config.baseFare,
    distanceFare,
    platformFee,
    totalGrossFare,
    subsidyPercentage,
    companySubsidyAmount,
    customerPayableFare,
    driverGrossEarnings,
    etaMins
  };
}
