import {
  CustomerUser,
  DriverUser,
  FareConfig,
  Language,
  LocationPoint,
  PaymentMethod,
  RideBooking,
  RideStatus,
  Role,
  SubsidyConfig,
  SupportTicket,
  VehicleCategory
} from '../types';
import {
  DEFAULT_FARE_CONFIG,
  DEFAULT_SUBSIDY_CONFIG,
  INITIAL_CUSTOMER,
  INITIAL_DRIVERS,
  INITIAL_LOCATIONS,
  INITIAL_PAST_RIDES
} from '../data/mockData';
import { calculateFare } from './pricing';
import { playRideAlertChime, playSuccessChime } from './audio';

const STORAGE_KEY = 'odisha_ride_state_v1';

export interface AppState {
  currentRole: Role;
  splitView: boolean;
  language: Language;
  
  customer: CustomerUser;
  selectedDriverId: string;
  drivers: DriverUser[];
  
  activeRide: RideBooking | null;
  rideHistory: RideBooking[];
  
  fareConfig: FareConfig;
  subsidyConfig: SubsidyConfig;
  supportTickets: SupportTicket[];
}

function getInitialState(): AppState {
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          currentRole: parsed.currentRole || 'customer',
          splitView: parsed.splitView ?? false,
          language: parsed.language || 'en',
          customer: parsed.customer || INITIAL_CUSTOMER,
          selectedDriverId: parsed.selectedDriverId || INITIAL_DRIVERS[0].id,
          drivers: parsed.drivers || INITIAL_DRIVERS,
          activeRide: parsed.activeRide || null,
          rideHistory: parsed.rideHistory || INITIAL_PAST_RIDES,
          fareConfig: parsed.fareConfig || DEFAULT_FARE_CONFIG,
          subsidyConfig: parsed.subsidyConfig || DEFAULT_SUBSIDY_CONFIG,
          supportTickets: parsed.supportTickets || [
            {
              id: 'ticket-01',
              userType: 'customer',
              userId: 'cust-demo-01',
              userName: 'Bapina Senapati',
              subject: 'Inquiry on 50% Subsidy duration',
              message: 'Is the 50% Odisha Ride subsidy valid for all rides between Bhubaneswar and Cuttack?',
              status: 'resolved',
              createdAt: '2026-11-03T10:00:00Z'
            }
          ]
        };
      }
    } catch {
      // fallback
    }
  }

  return {
    currentRole: 'customer',
    splitView: false,
    language: 'en',
    customer: INITIAL_CUSTOMER,
    selectedDriverId: INITIAL_DRIVERS[0].id,
    drivers: INITIAL_DRIVERS,
    activeRide: null,
    rideHistory: INITIAL_PAST_RIDES,
    fareConfig: DEFAULT_FARE_CONFIG,
    subsidyConfig: DEFAULT_SUBSIDY_CONFIG,
    supportTickets: [
      {
        id: 'ticket-01',
        userType: 'customer',
        userId: 'cust-demo-01',
        userName: 'Bapina Senapati',
        subject: 'Inquiry on 50% Subsidy duration',
        message: 'Is the 50% Odisha Ride subsidy valid for all rides between Bhubaneswar and Cuttack?',
        status: 'resolved',
        createdAt: '2026-11-03T10:00:00Z'
      }
    ]
  };
}

let currentState: AppState = getInitialState();
const listeners = new Set<(state: AppState) => void>();

function notify() {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(currentState));
    } catch {
      // ignore quota
    }
  }
  listeners.forEach((listener) => listener({ ...currentState }));
}

export const store = {
  getState: (): AppState => ({ ...currentState }),

  subscribe: (listener: (state: AppState) => void) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  setRole: (role: Role) => {
    currentState.currentRole = role;
    notify();
  },

  setSplitView: (split: boolean) => {
    currentState.splitView = split;
    notify();
  },

  setLanguage: (lang: Language) => {
    currentState.language = lang;
    notify();
  },

  setSelectedDriverId: (driverId: string) => {
    currentState.selectedDriverId = driverId;
    notify();
  },

  updateCustomerProfile: (data: Partial<CustomerUser>) => {
    currentState.customer = { ...currentState.customer, ...data };
    notify();
  },

  loginCustomer: (phone: string, name?: string) => {
    currentState.customer = {
      ...currentState.customer,
      phone,
      name: name || currentState.customer.name || 'Bapina Senapati',
      isLoggedIn: true
    };
    notify();
  },

  logoutCustomer: () => {
    currentState.customer = {
      ...currentState.customer,
      isLoggedIn: false
    };
    notify();
  },

  addSavedPlace: (location: LocationPoint) => {
    const existing = currentState.customer.savedPlaces?.other || [];
    currentState.customer = {
      ...currentState.customer,
      savedPlaces: {
        ...currentState.customer.savedPlaces,
        other: [...existing, location]
      }
    };
    notify();
  },

  removeSavedPlace: (index: number) => {
    const existing = currentState.customer.savedPlaces?.other || [];
    currentState.customer = {
      ...currentState.customer,
      savedPlaces: {
        ...currentState.customer.savedPlaces,
        other: existing.filter((_, idx) => idx !== index)
      }
    };
    notify();
  },

  // --- BOOKING WORKFLOW ---
  createRideBooking: (
    pickup: LocationPoint,
    destination: LocationPoint,
    category: VehicleCategory
  ): RideBooking => {
    const fare = calculateFare(
      pickup,
      destination,
      category,
      currentState.fareConfig,
      currentState.subsidyConfig
    );

    // Generate random 4-digit start OTP
    const startOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const bookingRef = `OR-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRide: RideBooking = {
      id: `ride-${Date.now()}`,
      bookingRef,
      customerId: currentState.customer.id,
      customerName: currentState.customer.name,
      customerPhone: currentState.customer.phone,
      pickup,
      destination,
      vehicleCategory: category,
      status: 'searching',
      startOtp,
      distanceKm: fare.distanceKm,
      durationMins: fare.durationMins,
      baseFare: fare.baseFare,
      distanceFare: fare.distanceFare,
      platformFee: fare.platformFee,
      totalGrossFare: fare.totalGrossFare,
      subsidyPercentage: fare.subsidyPercentage,
      companySubsidyAmount: fare.companySubsidyAmount,
      customerPayableFare: fare.customerPayableFare,
      driverPayoutAmount: fare.driverGrossEarnings,
      isCompanyVehicle: false,
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      createdAt: new Date().toISOString()
    };

    currentState.activeRide = newRide;
    notify();

    // Trigger driver alert sound so driver app hears the ping!
    playRideAlertChime();

    return newRide;
  },

  // --- DEMO STAGE CONTROLLER (Allow testing stages without a real driver) ---
  setRideStatus: (targetStatus: RideStatus) => {
    if (!currentState.activeRide) return;

    if (targetStatus === 'searching') {
      currentState.activeRide = {
        ...currentState.activeRide,
        status: 'searching',
        driverId: undefined,
        driverName: undefined,
        driverPhone: undefined,
        driverPhotoUrl: undefined,
        driverRating: undefined,
        vehicleNumber: undefined,
        vehicleModel: undefined
      };
      notify();
      return;
    }

    // If advancing to driver_assigned or beyond, ensure driver is populated
    let driver = currentState.drivers.find((d) => d.id === currentState.activeRide?.driverId);
    if (!driver) {
      driver = currentState.drivers.find(
        (d) => d.isApproved && d.isOnline && d.vehicleCategory === currentState.activeRide?.vehicleCategory
      ) || currentState.drivers.find(
        (d) => d.isApproved && d.vehicleCategory === currentState.activeRide?.vehicleCategory
      ) || currentState.drivers[0];
    }

    const isCompanyVehicle = driver.vehicleOwnership === 'owner_company';

    if (targetStatus === 'driver_assigned') {
      currentState.activeRide = {
        ...currentState.activeRide,
        status: 'driver_assigned',
        driverId: driver.id,
        driverName: driver.name,
        driverPhone: driver.phone,
        driverPhotoUrl: driver.photoUrl,
        driverRating: driver.rating,
        vehicleNumber: driver.vehicleNumber,
        vehicleModel: driver.vehicleModel,
        vehicleOwnership: driver.vehicleOwnership,
        isCompanyVehicle,
        acceptedAt: currentState.activeRide.acceptedAt || new Date().toISOString()
      };
      playSuccessChime();
      notify();
    } else if (targetStatus === 'driver_arrived') {
      currentState.activeRide = {
        ...currentState.activeRide,
        status: 'driver_arrived',
        driverId: driver.id,
        driverName: driver.name,
        driverPhone: driver.phone,
        driverPhotoUrl: driver.photoUrl,
        driverRating: driver.rating,
        vehicleNumber: driver.vehicleNumber,
        vehicleModel: driver.vehicleModel,
        vehicleOwnership: driver.vehicleOwnership,
        isCompanyVehicle,
        arrivedAt: currentState.activeRide.arrivedAt || new Date().toISOString()
      };
      playSuccessChime();
      notify();
    } else if (targetStatus === 'in_progress') {
      currentState.activeRide = {
        ...currentState.activeRide,
        status: 'in_progress',
        driverId: driver.id,
        driverName: driver.name,
        driverPhone: driver.phone,
        driverPhotoUrl: driver.photoUrl,
        driverRating: driver.rating,
        vehicleNumber: driver.vehicleNumber,
        vehicleModel: driver.vehicleModel,
        vehicleOwnership: driver.vehicleOwnership,
        isCompanyVehicle,
        startedAt: currentState.activeRide.startedAt || new Date().toISOString()
      };
      playSuccessChime();
      notify();
    } else if (targetStatus === 'completed') {
      const completedRide: RideBooking = {
        ...currentState.activeRide,
        status: 'completed',
        driverId: driver.id,
        driverName: driver.name,
        driverPhone: driver.phone,
        driverPhotoUrl: driver.photoUrl,
        driverRating: driver.rating,
        vehicleNumber: driver.vehicleNumber,
        vehicleModel: driver.vehicleModel,
        vehicleOwnership: driver.vehicleOwnership,
        isCompanyVehicle,
        completedAt: new Date().toISOString()
      };
      currentState.activeRide = completedRide;
      // Prepend to history if not already present
      const alreadyInHist = currentState.rideHistory.some((r) => r.id === completedRide.id);
      if (!alreadyInHist) {
        currentState.rideHistory = [completedRide, ...currentState.rideHistory];
      }
      playSuccessChime();
      notify();
    }
  },

  driverAcceptBooking: (rideId: string, driverId: string): boolean => {
    if (!currentState.activeRide || currentState.activeRide.id !== rideId) return false;

    const driver = currentState.drivers.find((d) => d.id === driverId);
    if (!driver) return false;

    const isCompanyVehicle = driver.vehicleOwnership === 'owner_company';

    currentState.activeRide = {
      ...currentState.activeRide,
      status: 'driver_assigned',
      driverId: driver.id,
      driverName: driver.name,
      driverPhone: driver.phone,
      driverPhotoUrl: driver.photoUrl,
      driverRating: driver.rating,
      vehicleNumber: driver.vehicleNumber,
      vehicleModel: driver.vehicleModel,
      vehicleOwnership: driver.vehicleOwnership,
      isCompanyVehicle,
      acceptedAt: new Date().toISOString()
    };

    playSuccessChime();
    notify();
    return true;
  },

  driverArrivedAtPickup: (rideId: string) => {
    if (!currentState.activeRide || currentState.activeRide.id !== rideId) return;

    currentState.activeRide = {
      ...currentState.activeRide,
      status: 'driver_arrived',
      arrivedAt: new Date().toISOString()
    };
    playSuccessChime();
    notify();
  },

  driverStartRide: (rideId: string, enteredOtp: string): { success: boolean; message?: string } => {
    if (!currentState.activeRide || currentState.activeRide.id !== rideId) {
      return { success: false, message: 'No active ride found.' };
    }

    if (currentState.activeRide.startOtp !== enteredOtp.trim()) {
      return { success: false, message: 'Invalid 4-digit OTP. Ask customer for the code displayed on their app.' };
    }

    currentState.activeRide = {
      ...currentState.activeRide,
      status: 'in_progress',
      startedAt: new Date().toISOString()
    };
    notify();
    return { success: true };
  },

  driverCompleteRide: (rideId: string) => {
    if (!currentState.activeRide || currentState.activeRide.id !== rideId) return;

    const completedRide: RideBooking = {
      ...currentState.activeRide,
      status: 'completed',
      completedAt: new Date().toISOString()
    };

    currentState.activeRide = completedRide;
    // Append to ride history
    currentState.rideHistory = [completedRide, ...currentState.rideHistory];

    // Increment driver's completed trips
    if (completedRide.driverId) {
      currentState.drivers = currentState.drivers.map((d) =>
        d.id === completedRide.driverId ? { ...d, totalTrips: d.totalTrips + 1 } : d
      );
    }

    playSuccessChime();
    notify();
  },

  payRide: (rideId: string, method: PaymentMethod, transactionId?: string) => {
    const updateRide = (ride: RideBooking): RideBooking => ({
      ...ride,
      paymentMethod: method,
      paymentStatus: 'completed',
      transactionId: transactionId || `TXN-OR-${Date.now().toString().slice(-6)}`
    });

    if (currentState.activeRide && currentState.activeRide.id === rideId) {
      currentState.activeRide = updateRide(currentState.activeRide);
    }

    currentState.rideHistory = currentState.rideHistory.map((r) =>
      r.id === rideId ? updateRide(r) : r
    );

    playSuccessChime();
    notify();
  },

  rateDriver: (rideId: string, rating: number, review?: string) => {
    const updateRide = (ride: RideBooking): RideBooking => ({
      ...ride,
      ratingByCustomer: rating,
      reviewByCustomer: review
    });

    let targetDriverId: string | undefined;

    if (currentState.activeRide && currentState.activeRide.id === rideId) {
      currentState.activeRide = updateRide(currentState.activeRide);
      targetDriverId = currentState.activeRide.driverId;
    }
    currentState.rideHistory = currentState.rideHistory.map((r) => {
      if (r.id === rideId) {
        targetDriverId = r.driverId;
        return updateRide(r);
      }
      return r;
    });

    // Update driver's aggregate rating in drivers list
    if (targetDriverId) {
      currentState.drivers = currentState.drivers.map((d) => {
        if (d.id === targetDriverId) {
          const newAvg = Math.round(((d.rating * Math.max(1, d.totalTrips) + rating) / (Math.max(1, d.totalTrips) + 1)) * 10) / 10;
          return { ...d, rating: Number(newAvg.toFixed(1)) };
        }
        return d;
      });
    }

    notify();
  },

  cancelRide: (rideId: string, reason: string) => {
    if (currentState.activeRide && currentState.activeRide.id === rideId) {
      const cancelled: RideBooking = {
        ...currentState.activeRide,
        status: 'cancelled',
        cancelledAt: new Date().toISOString(),
        cancellationReason: reason
      };
      currentState.activeRide = null;
      currentState.rideHistory = [cancelled, ...currentState.rideHistory];
      notify();
    }
  },

  clearActiveRide: () => {
    currentState.activeRide = null;
    notify();
  },

  // --- DRIVER CONTROLS ---
  toggleDriverOnline: (driverId: string) => {
    currentState.drivers = currentState.drivers.map((d) =>
      d.id === driverId ? { ...d, isOnline: !d.isOnline } : d
    );
    notify();
  },

  registerNewDriver: (driverData: Omit<DriverUser, 'id' | 'rating' | 'totalTrips' | 'isOnline' | 'isApproved' | 'approvalStatus'>) => {
    const newDriver: DriverUser = {
      ...driverData,
      id: `drv-${Date.now()}`,
      rating: 5.0,
      totalTrips: 0,
      isOnline: false,
      isApproved: false,
      approvalStatus: 'pending'
    };
    currentState.drivers = [newDriver, ...currentState.drivers];
    currentState.selectedDriverId = newDriver.id;
    notify();
    return newDriver;
  },

  // --- ADMIN CONTROLS ---
  adminApproveDriver: (driverId: string) => {
    currentState.drivers = currentState.drivers.map((d) =>
      d.id === driverId
        ? { ...d, isApproved: true, approvalStatus: 'approved', rejectionReason: undefined }
        : d
    );
    notify();
  },

  adminRejectDriver: (driverId: string, reason: string) => {
    currentState.drivers = currentState.drivers.map((d) =>
      d.id === driverId
        ? { ...d, isApproved: false, approvalStatus: 'rejected', rejectionReason: reason, isOnline: false }
        : d
    );
    notify();
  },

  updateFareConfig: (config: FareConfig) => {
    currentState.fareConfig = config;
    notify();
  },

  updateSubsidyConfig: (subsidy: SubsidyConfig) => {
    currentState.subsidyConfig = subsidy;
    notify();
  },

  submitSupportTicket: (ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>) => {
    const newTicket: SupportTicket = {
      ...ticket,
      id: `tkt-${Date.now()}`,
      status: 'open',
      createdAt: new Date().toISOString()
    };
    currentState.supportTickets = [newTicket, ...currentState.supportTickets];
    notify();
  },

  resolveSupportTicket: (ticketId: string) => {
    currentState.supportTickets = currentState.supportTickets.map((t) =>
      t.id === ticketId ? { ...t, status: 'resolved' } : t
    );
    notify();
  },

  resetAllData: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY);
    }
    currentState = {
      currentRole: 'customer',
      splitView: false,
      language: 'en',
      customer: INITIAL_CUSTOMER,
      selectedDriverId: INITIAL_DRIVERS[0].id,
      drivers: INITIAL_DRIVERS,
      activeRide: null,
      rideHistory: INITIAL_PAST_RIDES,
      fareConfig: DEFAULT_FARE_CONFIG,
      subsidyConfig: DEFAULT_SUBSIDY_CONFIG,
      supportTickets: [
        {
          id: 'ticket-01',
          userType: 'customer',
          userId: 'cust-demo-01',
          userName: 'Bapina Senapati',
          subject: 'Inquiry on 50% Subsidy duration',
          message: 'Is the 50% Odisha Ride subsidy valid for all rides between Bhubaneswar and Cuttack?',
          status: 'resolved',
          createdAt: '2026-11-03T10:00:00Z'
        }
      ]
    };
    notify();
  }
};
