/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { store, AppState } from './services/store';
import { Header } from './components/common/Header';
import { CustomerApp } from './components/customer/CustomerApp';
import { DriverApp } from './components/driver/DriverApp';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Smartphone, CarFront } from 'lucide-react';

export default function App() {
  const [appState, setAppState] = useState<AppState>(store.getState());
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  useEffect(() => {
    const unsubscribe = store.subscribe((newState) => {
      setAppState(newState);
    });

    const handleQuotaExceeded = () => {
      setQuotaExceeded(true);
    };

    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);

    return () => {
      unsubscribe();
      window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white">
      {/* Mandatory Quota Notification Banner per GMP governance */}
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* 3-Zone Navigation Header */}
      <Header
        currentRole={appState.currentRole}
        splitView={appState.splitView}
        language={appState.language}
        onRoleChange={(role) => {
          store.setRole(role);
          if (appState.splitView) store.setSplitView(false);
        }}
        onSplitViewToggle={() => store.setSplitView(!appState.splitView)}
        onLanguageChange={(lang) => store.setLanguage(lang)}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full">
        {appState.splitView ? (
          /* Dual / Split Simulation Mode: Customer on Left, Driver on Right */
          <div className="w-full max-w-[1600px] mx-auto p-3 sm:p-5">
            <div className="mb-3 px-2 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs">
              <span className="font-bold text-orange-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Dual Device Simulation Mode Active
              </span>
              <span className="text-slate-400 hidden sm:inline">
                Test the complete live booking, GPS tracking, and payment lifecycle simultaneously
              </span>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
              {/* Left Screen: Customer App */}
              <div className="rounded-3xl border border-slate-800 bg-slate-950/70 p-2 sm:p-3 shadow-2xl">
                <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800 text-xs font-bold text-slate-300 mb-2">
                  <Smartphone className="w-4 h-4 text-orange-400" />
                  <span>Customer Phone View</span>
                </div>
                <CustomerApp appState={appState} />
              </div>

              {/* Right Screen: Driver Captain App */}
              <div className="rounded-3xl border border-slate-800 bg-slate-950/70 p-2 sm:p-3 shadow-2xl">
                <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800 text-xs font-bold text-slate-300 mb-2">
                  <CarFront className="w-4 h-4 text-emerald-400" />
                  <span>Captain Driver View</span>
                </div>
                <DriverApp appState={appState} />
              </div>
            </div>
          </div>
        ) : (
          /* Single Panel Mode */
          <>
            {appState.currentRole === 'customer' && <CustomerApp appState={appState} />}
            {appState.currentRole === 'driver' && <DriverApp appState={appState} />}
            {appState.currentRole === 'admin' && <AdminDashboard appState={appState} />}
          </>
        )}
      </main>

      {/* Global Minimal Footer */}
      <footer className="w-full border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <div className="flex flex-col sm:flex-row items-center justify-between max-w-7xl mx-auto gap-2">
          <span>© 2026 ODISHA RIDE Technologies Pvt Ltd · Bhubaneswar & Cuttack</span>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>50% Odisha Subsidy Phase</span>
            <span>·</span>
            <span>Auto Rickshaws & Cabs</span>
            <span>·</span>
            <span>Emergency SOS: 112</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
