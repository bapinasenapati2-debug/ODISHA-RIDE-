import React, { useState } from 'react';
import { RideBooking, Language } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import confetti from 'canvas-confetti';
import {
  Star,
  CheckCircle2,
  Car,
  Heart,
  MessageSquare,
  Sparkles,
  ShieldCheck,
  X,
  ThumbsUp,
  MapPin,
  Navigation
} from 'lucide-react';

interface PostRideRatingModalProps {
  ride: RideBooking;
  language: Language;
  onClose: () => void;
}

const POSITIVE_TAGS = [
  'Smooth Driving',
  'Polite Captain',
  'Clean Vehicle',
  'Followed Route',
  'On Time Pickup',
  'Comfortable AC',
  'Great Conversation'
];

const CRITICAL_TAGS = [
  'Rash Driving',
  'AC Not Working',
  'Late Arrival',
  'Unprofessional',
  'Took Longer Route',
  'Vehicle Not Clean'
];

const RATING_DESCRIPTIONS: Record<number, { title: string; desc: string }> = {
  1: { title: 'Poor', desc: 'We apologize. Please tell us what went wrong so we can take action.' },
  2: { title: 'Below Expectations', desc: 'Trip could have been better. We appreciate your feedback.' },
  3: { title: 'Average Trip', desc: 'Acceptable journey, but there is room for improvement.' },
  4: { title: 'Very Good', desc: 'Smooth and pleasant ride with our Captain.' },
  5: { title: 'Outstanding!', desc: 'Exceptional trip! Thank you for choosing ODISHA RIDE.' }
};

export const PostRideRatingModal: React.FC<PostRideRatingModalProps> = ({
  ride,
  language,
  onClose
}) => {
  const t = getTranslation(language);

  const [rating, setRating] = useState<number>(ride.ratingByCustomer || 5);
  const [hoveredStar, setHoveredStar] = useState<number | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [feedbackText, setFeedbackText] = useState(ride.reviewByCustomer || '');
  const [tipAmount, setTipAmount] = useState<number>(0);
  const [isSubmitted, setIsSubmitted] = useState(Boolean(ride.ratingByCustomer));

  const activeStar = hoveredStar !== null ? hoveredStar : rating;
  const currentTags = activeStar >= 4 ? POSITIVE_TAGS : CRITICAL_TAGS;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const compiledReview = [
      selectedTags.length > 0 ? `[${selectedTags.join(', ')}]` : '',
      feedbackText.trim(),
      tipAmount > 0 ? `(Tipped Captain ₹${tipAmount})` : ''
    ]
      .filter(Boolean)
      .join(' ');

    store.rateDriver(ride.id, rating, compiledReview);
    setIsSubmitted(true);

    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // safe fallback
    }

    setTimeout(() => {
      store.clearActiveRide();
      onClose();
    }, 1800);
  };

  const handleSkip = () => {
    store.clearActiveRide();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-2xl text-slate-100 my-auto relative animate-in fade-in zoom-in-95 duration-200">
        {/* Dismiss Button */}
        <button
          type="button"
          onClick={handleSkip}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors z-10"
          title="Skip rating"
        >
          <X className="w-4 h-4" />
        </button>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs">
            {/* Header / Trip Completion Pill */}
            <div className="text-center pt-1 pb-2 border-b border-slate-800">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold uppercase tracking-wider mb-2">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Trip Completed Successfully</span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white">
                How was your ride with {ride.driverName || 'our Captain'}?
              </h2>
              <p className="text-slate-400 text-xs mt-0.5">
                Ref: {ride.bookingRef} · {ride.pickup.city}
              </p>
            </div>

            {/* Captain & Vehicle Card */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 shadow-inner">
              <div className="flex items-center gap-3">
                <img
                  src={ride.driverPhotoUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'}
                  alt={ride.driverName}
                  referrerPolicy="no-referrer"
                  className="w-13 h-13 rounded-2xl object-cover border-2 border-orange-500/40 shadow-md"
                />
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    {ride.driverName || 'Captain'}
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30 font-semibold">
                      {ride.vehicleCategory === 'auto' ? 'Auto Rickshaw' : 'Cab'}
                    </span>
                  </h4>
                  <p className="text-slate-300 text-[11px]">{ride.vehicleModel || 'Odisha Ride Vehicle'}</p>
                  <span className="font-mono text-[11px] font-bold text-orange-400 inline-block mt-0.5">
                    {ride.vehicleNumber || 'OD-02-AX-XXXX'}
                  </span>
                </div>
              </div>

              {/* Trip route snippet */}
              <div className="text-right hidden sm:block">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Route</span>
                <span className="text-slate-300 font-medium block truncate max-w-[130px]">
                  {ride.pickup.name.split('(')[0]}
                </span>
                <span className="text-slate-400 text-[10px] font-mono">
                  {ride.distanceKm} km · ₹{ride.customerPayableFare}
                </span>
              </div>
            </div>

            {/* Interactive Star Rating Selector */}
            <div className="flex flex-col items-center justify-center py-2 px-3 rounded-2xl bg-slate-950/50 border border-slate-800">
              <div className="flex items-center gap-2 sm:gap-3 py-1">
                {[1, 2, 3, 4, 5].map((star) => {
                  const isFilled = star <= activeStar;
                  return (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoveredStar(star)}
                      onMouseLeave={() => setHoveredStar(null)}
                      className="p-1 transition-transform hover:scale-125 active:scale-95 focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 sm:w-10 sm:h-10 transition-colors drop-shadow-md ${
                          isFilled
                            ? 'text-amber-400 fill-amber-400 filter drop-shadow-[0_2px_8px_rgba(251,191,36,0.5)]'
                            : 'text-slate-600 hover:text-slate-400'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>

              {/* Rating Description Label */}
              <div className="text-center mt-1">
                <span className="text-sm font-extrabold text-amber-400 font-display">
                  {activeStar} Star{activeStar > 1 ? 's' : ''} — {RATING_DESCRIPTIONS[activeStar].title}
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5 max-w-sm">
                  {RATING_DESCRIPTIONS[activeStar].desc}
                </p>
              </div>
            </div>

            {/* Quick Feedback Tags */}
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-2">
                {activeStar >= 4 ? 'What did you like the most?' : 'What can be improved?'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {currentTags.map((tag) => {
                  const isSelected = selectedTags.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 border ${
                        isSelected
                          ? 'bg-orange-500 text-white border-orange-400 shadow-sm'
                          : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <span>{tag}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Detailed Written Feedback (Optional) */}
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1 flex items-center justify-between">
                <span>Detailed Comments (Optional)</span>
                <span className="text-slate-500 font-normal">{feedbackText.length}/200</span>
              </label>
              <textarea
                rows={2}
                maxLength={200}
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
                placeholder="Share any other feedback about the driving, vehicle condition, or route..."
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-600 focus:border-orange-500 focus:outline-none transition-colors"
              />
            </div>

            {/* Optional Captain Tip */}
            {activeStar >= 4 && (
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                    Add a Tip for Captain (100% goes to driver)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {[0, 10, 20, 50].map((amount) => (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => setTipAmount(amount)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                        tipAmount === amount
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {amount === 0 ? 'No Tip' : `+₹${amount}`}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 50% Subsidy Trip Summary Notice */}
            <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-[11px]">
              <span className="text-slate-400">Total Fare: ₹{ride.totalGrossFare}</span>
              <span className="text-emerald-400 font-semibold">
                You saved ₹{ride.companySubsidyAmount} with 50% Odisha Subsidy!
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={handleSkip}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
              >
                Skip
              </button>

              <button
                type="submit"
                className="flex-2 py-3 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg shadow-orange-500/30 transition-all flex items-center justify-center gap-2 transform active:scale-95"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Rating & Feedback</span>
              </button>
            </div>
          </form>
        ) : (
          /* Post-Submit Confirmation Splash */
          <div className="flex flex-col items-center justify-center py-8 text-center gap-3">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shadow-lg border border-emerald-500/40 animate-bounce">
              <ThumbsUp className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-white">
              Thank You for Rating!
            </h3>
            <p className="text-xs text-slate-300 max-w-sm">
              Your {rating}-star rating and feedback have been shared with Captain {ride.driverName}. Your feedback helps keep ODISHA RIDE safe and reliable across Bhubaneswar & Cuttack.
            </p>
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-xs font-mono text-orange-400">
              <Sparkles className="w-3.5 h-3.5 text-orange-400" />
              <span>Enjoy your day in Odisha!</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
