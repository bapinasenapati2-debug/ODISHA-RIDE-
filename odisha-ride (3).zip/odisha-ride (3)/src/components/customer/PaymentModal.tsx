import React, { useState } from 'react';
import { RideBooking, PaymentMethod, Language } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import confetti from 'canvas-confetti';
import {
  QrCode,
  CreditCard,
  Banknote,
  CheckCircle2,
  ShieldCheck,
  Smartphone,
  Star,
  Download,
  X,
  Zap
} from 'lucide-react';

interface PaymentModalProps {
  ride: RideBooking;
  language: Language;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  ride,
  language,
  onClose
}) => {
  const t = getTranslation(language);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>(ride.paymentMethod || 'upi_qr');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(ride.paymentStatus === 'completed');
  const [txnId, setTxnId] = useState(ride.transactionId || '');
  
  // Rating & Review state
  const [rating, setRating] = useState(ride.ratingByCustomer || 5);
  const [review, setReview] = useState(ride.reviewByCustomer || '');
  const [reviewSubmitted, setReviewSubmitted] = useState(Boolean(ride.ratingByCustomer));

  const handleProcessPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      const generatedTxnId =
        selectedMethod === 'upi_qr'
          ? `UPI-OD-${Date.now().toString().slice(-8)}`
          : selectedMethod === 'online'
          ? `RZP-OR-${Date.now().toString().slice(-8)}`
          : `CASH-DRV-${Date.now().toString().slice(-6)}`;
      setTxnId(generatedTxnId);
      store.payRide(ride.id, selectedMethod, generatedTxnId);

      try {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch {
        // fallback
      }
    }, 1200);
  };

  const handleRatingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    store.rateDriver(ride.id, rating, review);
    setReviewSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-slate-100 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-500/20 text-orange-400">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {isSuccess ? t.rideReceipt : t.paymentTitle}
              </h3>
              <p className="text-[10px] text-slate-400">Booking Ref: {ride.bookingRef}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Amount & 50% Subsidy Card */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400">Standard Approved Fare</span>
            <span className="text-xs font-mono text-slate-500 line-through">₹{ride.totalGrossFare}</span>
          </div>
          <div className="flex items-center justify-between mb-2 text-emerald-400 text-xs font-medium">
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              Odisha 50% Subsidy
            </span>
            <span className="font-mono">-₹{ride.companySubsidyAmount}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-xs font-bold text-white">Customer Amount Payable</span>
            <span className="text-2xl font-black text-orange-400 font-mono tabular-nums">
              ₹{ride.customerPayableFare}
            </span>
          </div>
        </div>

        {!isSuccess ? (
          /* Payment Methods Selection */
          <div className="flex flex-col gap-3">
            <span className="text-xs font-semibold text-slate-400">
              {t.paymentMethod}
            </span>

            {/* Option A: Verified Company UPI QR Code */}
            <label
              className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                selectedMethod === 'upi_qr'
                  ? 'border-orange-500 bg-orange-500/10 ring-1 ring-orange-500/40'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="paymentMethod"
                value="upi_qr"
                checked={selectedMethod === 'upi_qr'}
                onChange={() => setSelectedMethod('upi_qr')}
                className="mt-1 accent-orange-500"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <QrCode className="w-4 h-4 text-orange-400" />
                  <span className="text-xs font-bold text-white">Company UPI QR Code</span>
                </div>
                <p className="text-[11px] text-slate-400 mb-2">
                  Instant scan via Google Pay, PhonePe, or Paytm to official verified Odisha Ride VPA: <span className="font-mono text-orange-400 font-semibold">odisharide@upi</span>
                </p>
                {selectedMethod === 'upi_qr' && (
                  <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-white text-slate-900 mt-2 shadow-inner">
                    {/* SVG representation of Company QR code */}
                    <div className="w-32 h-32 bg-slate-900 p-2 rounded-lg flex items-center justify-center">
                      <svg viewBox="0 0 100 100" className="w-full h-full fill-white">
                        <path d="M10,10 h30 v30 h-30 z M15,15 v20 h20 v-20 z M20,20 h10 v10 h-10 z" />
                        <path d="M60,10 h30 v30 h-30 z M65,15 v20 h20 v-20 z M70,20 h10 v10 h-10 z" />
                        <path d="M10,60 h30 v30 h-30 z M15,65 v20 h20 v-20 z M20,70 h10 v10 h-10 z" />
                        <rect x="50" y="50" width="10" height="10" />
                        <rect x="65" y="50" width="10" height="10" />
                        <rect x="80" y="50" width="10" height="10" />
                        <rect x="50" y="65" width="10" height="10" />
                        <rect x="65" y="80" width="10" height="10" />
                        <rect x="80" y="65" width="10" height="25" />
                        <rect x="50" y="80" width="10" height="10" />
                      </svg>
                    </div>
                    <span className="text-[10px] font-mono font-bold mt-1 text-slate-800">
                      Scan to Pay ₹{ride.customerPayableFare}
                    </span>
                  </div>
                )}
              </div>
            </label>

            {/* Option B: Online Gateway (Razorpay/Cashfree) */}
            <label
              className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                selectedMethod === 'online'
                  ? 'border-orange-500 bg-orange-500/10 ring-1 ring-orange-500/40'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="paymentMethod"
                value="online"
                checked={selectedMethod === 'online'}
                onChange={() => setSelectedMethod('online')}
                className="mt-1 accent-orange-500"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-orange-400" />
                  <span className="text-xs font-bold text-white">Online Payment Gateway</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Razorpay / Cashfree secured checkout with Debit Cards, Credit Cards, NetBanking.
                </p>
              </div>
            </label>

            {/* Option C: Cash Payment to Driver */}
            <label
              className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                selectedMethod === 'cash'
                  ? 'border-orange-500 bg-orange-500/10 ring-1 ring-orange-500/40'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="paymentMethod"
                value="cash"
                checked={selectedMethod === 'cash'}
                onChange={() => setSelectedMethod('cash')}
                className="mt-1 accent-orange-500"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Banknote className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">Direct Cash to Driver</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Hand exact cash (₹{ride.customerPayableFare}) directly to {ride.driverName || 'driver'}.
                </p>
              </div>
            </label>

            {/* Action CTA */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleProcessPayment}
              className="mt-2 w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg shadow-orange-500/25 transition-all disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  <span>Verifying Transaction...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Pay ₹{ride.customerPayableFare} via {selectedMethod === 'upi_qr' ? 'UPI' : selectedMethod === 'online' ? 'Gateway' : 'Cash'}</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* Trip Completed & Receipt Details with Driver Rating */
          <div className="flex flex-col gap-3">
            <div className="flex flex-col items-center p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-1" />
              <h4 className="text-sm font-bold text-white">Payment Recorded Successfully</h4>
              <p className="text-[11px] font-mono text-emerald-300">
                Txn ID: {txnId || ride.transactionId}
              </p>
            </div>

            {/* Official Receipt Line Items */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-col gap-2">
              <div className="flex justify-between text-slate-400">
                <span>Vehicle:</span>
                <span className="font-semibold text-slate-200">{ride.vehicleModel} ({ride.vehicleNumber})</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Driver:</span>
                <span className="font-semibold text-slate-200">{ride.driverName}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Distance & Time:</span>
                <span className="font-semibold text-slate-200">{ride.distanceKm} km · {ride.durationMins} mins</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Payment Mode:</span>
                <span className="font-semibold uppercase text-orange-400">{ride.paymentMethod}</span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between font-bold text-white">
                <span>Customer Amount Paid:</span>
                <span className="text-orange-400 font-mono text-sm">₹{ride.customerPayableFare}</span>
              </div>
              <div className="flex justify-between text-[11px] text-emerald-400 font-medium">
                <span>Odisha 50% Subsidy Disbursed:</span>
                <span className="font-mono">₹{ride.companySubsidyAmount}</span>
              </div>
            </div>

            {/* Driver Rating & Review Form */}
            {!reviewSubmitted ? (
              <form onSubmit={handleRatingSubmit} className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="block text-xs font-bold text-slate-200 mb-2">
                  {t.rateDriver}
                </span>
                <div className="flex items-center gap-2 mb-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 text-amber-400 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs text-amber-400 font-bold ml-1 font-mono">
                    {rating}.0 / 5
                  </span>
                </div>
                <textarea
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  placeholder="Share feedback (e.g., Clean vehicle, polite driver, safe driving...)"
                  rows={2}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:border-orange-500 focus:outline-none mb-2"
                />
                <button
                  type="submit"
                  className="w-full py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold shadow"
                >
                  {t.submitReview}
                </button>
              </form>
            ) : (
              <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center text-xs text-amber-400 font-medium">
                ★ Thank you for rating your trip with {rating} stars!
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                store.clearActiveRide();
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Done & Book Another Ride
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
