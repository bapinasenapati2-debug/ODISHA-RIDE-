import React, { useState } from 'react';
import { LocationPoint, VehicleCategory, Language, PaymentMethod } from '../../types';
import { INITIAL_LOCATIONS } from '../../data/mockData';
import { calculateFare, calculateDriverEta } from '../../services/pricing';
import { store, AppState } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import {
  MapPin,
  Navigation,
  ArrowUpDown,
  Car,
  Clock,
  CheckCircle2,
  Sparkles,
  Zap,
  LocateFixed,
  Search,
  Plus,
  Bike,
  CreditCard,
  Banknote,
  QrCode,
  ShieldCheck
} from 'lucide-react';

interface RideBookingCardProps {
  appState: AppState;
  pickup: LocationPoint | null;
  destination: LocationPoint | null;
  onSetPickup: (loc: LocationPoint) => void;
  onSetDestination: (loc: LocationPoint) => void;
  onSelectMapMode: (mode: 'pickup' | 'destination' | null) => void;
  selectionMode: 'pickup' | 'destination' | null;
  language: Language;
}

export const RideBookingCard: React.FC<RideBookingCardProps> = ({
  appState,
  pickup,
  destination,
  onSetPickup,
  onSetDestination,
  onSelectMapMode,
  selectionMode,
  language
}) => {
  const t = getTranslation(language);
  const [category, setCategory] = useState<VehicleCategory>('auto');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [showLocationPicker, setShowLocationPicker] = useState<'pickup' | 'destination' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState<'all' | 'Bhubaneswar' | 'Cuttack'>('all');
  const [customLocationText, setCustomLocationText] = useState('');
  const [geoLocating, setGeoLocating] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);

  const swapLocations = () => {
    if (pickup && destination) {
      const temp = pickup;
      onSetPickup(destination);
      onSetDestination(temp);
    }
  };

  const fareCalc =
    pickup && destination
      ? calculateFare(pickup, destination, category, appState.fareConfig, appState.subsidyConfig)
      : null;

  // Calculate quick preview fares for all 3 categories
  const bikeFare =
    pickup && destination
      ? calculateFare(pickup, destination, 'bike', appState.fareConfig, appState.subsidyConfig)
      : null;
  const autoFare =
    pickup && destination
      ? calculateFare(pickup, destination, 'auto', appState.fareConfig, appState.subsidyConfig)
      : null;
  const cabFare =
    pickup && destination
      ? calculateFare(pickup, destination, 'cab', appState.fareConfig, appState.subsidyConfig)
      : null;

  const handleUseCurrentLocation = (type: 'pickup' | 'destination') => {
    if (!navigator.geolocation) {
      // Fallback to Master Canteen for Bhubaneswar
      const fallback = INITIAL_LOCATIONS[0];
      if (type === 'pickup') onSetPickup(fallback);
      else onSetDestination(fallback);
      return;
    }

    setGeoLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoLocating(false);
        const { latitude, longitude } = pos.coords;
        const currentLoc: LocationPoint = {
          name: 'Current GPS Location',
          address: `${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°E (Bhubaneswar/Cuttack)`,
          lat: latitude,
          lng: longitude,
          city: latitude > 20.4 ? 'Cuttack' : 'Bhubaneswar'
        };
        if (type === 'pickup') onSetPickup(currentLoc);
        else onSetDestination(currentLoc);
        setShowLocationPicker(null);
      },
      () => {
        // Fallback default on permission denial
        setGeoLocating(false);
        const fallback = INITIAL_LOCATIONS[0];
        if (type === 'pickup') onSetPickup(fallback);
        else onSetDestination(fallback);
        setShowLocationPicker(null);
      },
      { timeout: 7000 }
    );
  };

  const handleAddManualCustomLocation = (type: 'pickup' | 'destination') => {
    if (!customLocationText.trim()) return;
    const isCuttack = customLocationText.toLowerCase().includes('cuttack');
    const newLoc: LocationPoint = {
      name: customLocationText.trim(),
      address: `${customLocationText.trim()}, ${isCuttack ? 'Cuttack' : 'Bhubaneswar'}, Odisha`,
      lat: isCuttack ? 20.4650 : 20.2960,
      lng: isCuttack ? 85.8800 : 85.8245,
      city: isCuttack ? 'Cuttack' : 'Bhubaneswar'
    };
    if (type === 'pickup') onSetPickup(newLoc);
    else onSetDestination(newLoc);
    setCustomLocationText('');
    setShowLocationPicker(null);
  };

  const filteredLocations = INITIAL_LOCATIONS.filter((loc) => {
    const matchesQuery =
      loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.address.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = cityFilter === 'all' || loc.city === cityFilter;
    return matchesQuery && matchesCity;
  });

  const handleBookRide = () => {
    if (!pickup || !destination) {
      setBookingError('Please select both pickup and drop-off locations.');
      return;
    }
    setBookingError(null);
    const ride = store.createRideBooking(pickup, destination, category);
    if (paymentMethod !== 'cash') {
      store.payRide(ride.id, paymentMethod);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Location Selector Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-4 shadow-xl backdrop-blur-md">
        <div className="relative flex flex-col gap-2.5">
          {/* Pickup Input */}
          <div className="relative">
            <div className="flex items-center gap-3 rounded-xl border border-slate-700/80 bg-slate-950/70 p-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400">
                <MapPin className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <label className="block text-[11px] font-medium text-slate-400">
                  {t.pickupLocation}
                </label>
                <button
                  type="button"
                  onClick={() => setShowLocationPicker('pickup')}
                  className="w-full text-left text-sm font-semibold text-white truncate focus:outline-none"
                >
                  {pickup ? pickup.name : 'Select pickup point...'}
                </button>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => handleUseCurrentLocation('pickup')}
                  title="Use My GPS Location"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 transition-colors"
                >
                  <LocateFixed className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectMapMode(selectionMode === 'pickup' ? null : 'pickup')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    selectionMode === 'pickup'
                      ? 'bg-orange-500 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {selectionMode === 'pickup' ? 'Picking...' : t.chooseOnMap}
                </button>
              </div>
            </div>
          </div>

          {/* Swap Button */}
          <div className="absolute right-14 top-1/2 -translate-y-1/2 z-10">
            <button
              type="button"
              onClick={swapLocations}
              title="Swap pickup and destination"
              className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-800 border border-slate-700 text-slate-300 hover:text-white shadow-md transition-transform active:scale-95"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Destination Input */}
          <div className="relative">
            <div className="flex items-center gap-3 rounded-xl border border-slate-700/80 bg-slate-950/70 p-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-rose-500/10 text-rose-400">
                <Navigation className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <label className="block text-[11px] font-medium text-slate-400">
                  {t.dropLocation}
                </label>
                <button
                  type="button"
                  onClick={() => setShowLocationPicker('destination')}
                  className="w-full text-left text-sm font-semibold text-white truncate focus:outline-none"
                >
                  {destination ? destination.name : 'Select destination...'}
                </button>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => handleUseCurrentLocation('destination')}
                  title="Use My GPS Location"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400 transition-colors"
                >
                  <LocateFixed className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectMapMode(selectionMode === 'destination' ? null : 'destination')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    selectionMode === 'destination'
                      ? 'bg-orange-500 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {selectionMode === 'destination' ? 'Picking...' : t.chooseOnMap}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Location Picker Drawer / Modal */}
        {showLocationPicker && (
          <div className="mt-3 pt-3 border-t border-slate-800 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">
                Select {showLocationPicker === 'pickup' ? 'Pickup' : 'Drop-off'} in Odisha
              </span>
              <button
                type="button"
                onClick={() => setShowLocationPicker(null)}
                className="text-xs text-orange-400 hover:underline"
              >
                Close
              </button>
            </div>

            {/* Manual Text Entry Input */}
            <div className="flex items-center gap-1.5">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search hub or address in BBSR / CTC..."
                  className="w-full pl-8 pr-3 py-2 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
              <button
                type="button"
                onClick={() => handleUseCurrentLocation(showLocationPicker)}
                className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold flex items-center gap-1 shrink-0"
              >
                <LocateFixed className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">GPS</span>
              </button>
            </div>

            {/* City Tabs */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <span className="text-slate-500">City:</span>
              {(['all', 'Bhubaneswar', 'Cuttack'] as const).map((city) => (
                <button
                  key={city}
                  type="button"
                  onClick={() => setCityFilter(city)}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    cityFilter === city
                      ? 'bg-orange-500 text-white'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {city === 'all' ? 'All Odisha' : city}
                </button>
              ))}
            </div>

            {/* Custom Location Text Input if address not in predefined hubs */}
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2">
              <input
                type="text"
                value={customLocationText}
                onChange={(e) => setCustomLocationText(e.target.value)}
                placeholder="Or type custom address..."
                className="bg-transparent text-xs text-white placeholder-slate-500 flex-1 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleAddManualCustomLocation(showLocationPicker)}
                disabled={!customLocationText.trim()}
                className="px-2.5 py-1 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white text-[11px] font-bold shrink-0 transition-colors"
              >
                Set Location
              </button>
            </div>

            {/* Location List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
              {filteredLocations.map((loc, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if (showLocationPicker === 'pickup') {
                      onSetPickup(loc);
                    } else {
                      onSetDestination(loc);
                    }
                    setShowLocationPicker(null);
                  }}
                  className="flex items-start gap-2 p-2 rounded-lg bg-slate-950/60 hover:bg-slate-800 text-left transition-colors border border-slate-800/80"
                >
                  <MapPin className="h-3.5 w-3.5 text-orange-400 shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-slate-200 truncate">{loc.name}</p>
                    <p className="text-[10px] text-slate-500 truncate">{loc.city} · {loc.address}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Vehicle Category Selector (Auto Rickshaw, Bike Taxi, Car / Cab) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-4 shadow-xl backdrop-blur-md">
        <div className="flex items-center justify-between mb-2.5">
          <label className="text-xs font-semibold text-slate-400">
            {t.selectVehicle} (3 Categories)
          </label>
          <span className="text-[11px] text-orange-400 font-medium">Bhubaneswar & Cuttack Fleet</span>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {/* Option 1: Bike Taxi */}
          <button
            type="button"
            onClick={() => setCategory('bike')}
            className={`relative flex flex-col p-2.5 sm:p-3 rounded-xl border text-left transition-all ${
              category === 'bike'
                ? 'border-orange-500 bg-orange-500/10 ring-2 ring-orange-500/30'
                : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wide">
                2-Wheeler
              </span>
              <span className="text-[9px] text-slate-400">2 min</span>
            </div>
            <div className="flex items-center gap-1.5 mb-1">
              <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Bike className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-bold text-white truncate">Bike Taxi</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight line-clamp-1 mb-1">
              Fastest in city traffic
            </p>
            {bikeFare && (
              <div className="mt-auto pt-1 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">Est.</span>
                <span className="text-xs font-bold font-mono text-orange-400">₹{bikeFare.customerPayableFare}</span>
              </div>
            )}
          </button>

          {/* Option 2: Auto Rickshaw (Three Wheeler) */}
          <button
            type="button"
            onClick={() => setCategory('auto')}
            className={`relative flex flex-col p-2.5 sm:p-3 rounded-xl border text-left transition-all ${
              category === 'auto'
                ? 'border-orange-500 bg-orange-500/10 ring-2 ring-orange-500/30'
                : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wide">
                3-Wheeler
              </span>
              <span className="text-[9px] text-slate-400">3 min</span>
            </div>
            <div className="flex items-center gap-1.5 mb-1">
              <div className="p-1 rounded-lg bg-amber-500/20 text-amber-400">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M19 12h-2V8a2 2 0 0 0-2-2H8l-3 4H2v2h2v4a2 2 0 0 0 2 2h1a2 2 0 0 0 4 0h6a2 2 0 0 0 4 0h1v-4a2 2 0 0 0-2-2zm-12 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm10 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm-4-10H8.5l1.8-2.4c.1-.1.3-.2.5-.2h2.2v4.6z" />
                </svg>
              </div>
              <span className="text-xs sm:text-sm font-bold text-white truncate">Auto</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight line-clamp-1 mb-1">
              3 Seats · Budget
            </p>
            {autoFare && (
              <div className="mt-auto pt-1 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">Est.</span>
                <span className="text-xs font-bold font-mono text-orange-400">₹{autoFare.customerPayableFare}</span>
              </div>
            )}
          </button>

          {/* Option 3: Car / Cab / Taxi (Four Wheeler) */}
          <button
            type="button"
            onClick={() => setCategory('cab')}
            className={`relative flex flex-col p-2.5 sm:p-3 rounded-xl border text-left transition-all ${
              category === 'cab'
                ? 'border-orange-500 bg-orange-500/10 ring-2 ring-orange-500/30'
                : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wide">
                4-Wheeler
              </span>
              <span className="text-[9px] text-slate-400">5 min</span>
            </div>
            <div className="flex items-center gap-1.5 mb-1">
              <div className="p-1 rounded-lg bg-orange-500/20 text-orange-400">
                <Car className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-bold text-white truncate">Cab / Taxi</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight line-clamp-1 mb-1">
              4 Seats · AC Comfort
            </p>
            {cabFare && (
              <div className="mt-auto pt-1 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">Est.</span>
                <span className="text-xs font-bold font-mono text-orange-400">₹{cabFare.customerPayableFare}</span>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Payment Option Selector */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-3.5 shadow-xl backdrop-blur-md">
        <label className="block text-xs font-semibold text-slate-400 mb-2">
          Payment Method
        </label>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <button
            type="button"
            onClick={() => setPaymentMethod('cash')}
            className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all ${
              paymentMethod === 'cash'
                ? 'border-orange-500 bg-orange-500/15 text-white'
                : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            <Banknote className="w-4 h-4 text-emerald-400" />
            <div className="text-left">
              <p className="font-bold text-xs">Cash Payment</p>
              <p className="text-[10px] text-slate-500">Pay captain after ride</p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setPaymentMethod('upi_qr')}
            className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all ${
              paymentMethod === 'upi_qr'
                ? 'border-orange-500 bg-orange-500/15 text-white'
                : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4 text-orange-400" />
            <div className="text-left">
              <p className="font-bold text-xs">UPI / QR Code</p>
              <p className="text-[10px] text-slate-500">PhonePe / GPay / Paytm</p>
            </div>
          </button>
        </div>
      </div>

      {/* Fare Estimate Breakdown Card */}
      {fareCalc ? (
        <div className="rounded-2xl border border-orange-500/30 bg-gradient-to-br from-slate-900 to-slate-950 p-4 shadow-xl backdrop-blur-md">
          {/* 50% Subsidy Banner */}
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-300 text-xs font-semibold mb-3">
            <Sparkles className="w-4 h-4 text-orange-400 shrink-0" />
            <span>{t.subsidyBanner}</span>
          </div>

          {/* Route Metrics: Distance & ETA */}
          <div className="flex items-center justify-between py-2 border-b border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-slate-500" />
              <span>Distance in KM:</span>
              <span className="font-semibold text-slate-200 font-mono tabular-nums">{fareCalc.distanceKm} km</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.estTime}:</span>
              <span className="font-semibold text-slate-200 font-mono tabular-nums">{fareCalc.durationMins} mins</span>
            </div>
          </div>

          {/* Transparent Ledger Breakdown requested by user */}
          <div className="flex flex-col gap-1.5 pt-3 pb-1 text-xs">
            <div className="flex items-center justify-between text-slate-400">
              <span>Base Fare ({category === 'bike' ? 'First 1.5 km' : category === 'auto' ? 'First 1.5 km' : 'First 2.0 km'})</span>
              <span className="font-mono tabular-nums text-slate-200">₹{fareCalc.baseFare}</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Per KM Charge (₹{category === 'bike' ? 9 : category === 'auto' ? 14 : 20}/km)</span>
              <span className="font-mono tabular-nums text-slate-200">₹{fareCalc.distanceFare}</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Odisha Ride Platform Fee</span>
              <span className="font-mono tabular-nums text-slate-200">₹{fareCalc.platformFee}</span>
            </div>
            <div className="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-800/60 font-semibold">
              <span>Total Estimated Fare</span>
              <span className="font-mono tabular-nums line-through text-slate-500">₹{fareCalc.totalGrossFare}</span>
            </div>
            <div className="flex items-center justify-between text-emerald-400 font-medium">
              <span className="flex items-center gap-1">
                <Zap className="w-3.5 h-3.5" />
                Odisha Govt Subsidy ({fareCalc.subsidyPercentage}%)
              </span>
              <span className="font-mono tabular-nums">-₹{fareCalc.companySubsidyAmount}</span>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-sm font-bold text-white">
              <span>Customer Payable ({paymentMethod.toUpperCase()})</span>
              <span className="text-xl text-orange-400 font-mono tabular-nums font-extrabold">
                ₹{fareCalc.customerPayableFare}
              </span>
            </div>
            <p className="text-[10px] text-slate-500 mt-1 italic">
              * Captain receives full ₹{fareCalc.driverGrossEarnings} approved payout upon trip completion.
            </p>
          </div>

          {bookingError && (
            <p className="text-xs text-rose-400 mt-2 font-medium">{bookingError}</p>
          )}

          {/* Confirm Booking CTA Button */}
          <button
            type="button"
            onClick={handleBookRide}
            className="mt-4 w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all transform active:scale-[0.99]"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>BOOK {category === 'bike' ? 'BIKE TAXI' : category === 'auto' ? 'AUTO RICKSHAW' : 'CAB'} NOW</span>
          </button>
        </div>
      ) : (
        <div className="rounded-2xl border border-slate-800/80 bg-slate-900/50 p-4 text-center">
          <p className="text-xs text-slate-400">
            Select pickup and destination in Bhubaneswar or Cuttack to calculate road distance, base fare, per KM charge, and 50% subsidized customer fare.
          </p>
        </div>
      )}
    </div>
  );
};
