import React, { useState, useEffect } from 'react';
import { RideBooking, Language, RideStatus } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import {
  Car,
  Bike,
  Phone,
  Shield,
  Star,
  Clock,
  AlertTriangle,
  XCircle,
  KeyRound,
  CheckCircle2,
  Navigation,
  Play,
  FastForward,
  Check,
  ChevronRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

interface LiveRideTrackerProps {
  ride: RideBooking;
  language: Language;
  onOpenPayment: () => void;
  onOpenSupport: () => void;
  onOpenRating?: () => void;
}

export const LiveRideTracker: React.FC<LiveRideTrackerProps> = ({
  ride,
  language,
  onOpenPayment,
  onOpenSupport,
  onOpenRating
}) => {
  const t = getTranslation(language);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('Change of plans');
  const [autoAdvance, setAutoAdvance] = useState(false);

  // Auto-advance simulation timer for demo
  useEffect(() => {
    if (!autoAdvance) return;
    if (ride.status === 'completed' || ride.status === 'cancelled') return;

    const timer = setTimeout(() => {
      if (ride.status === 'searching') {
        store.setRideStatus('driver_assigned');
      } else if (ride.status === 'driver_assigned') {
        store.setRideStatus('driver_arrived');
      } else if (ride.status === 'driver_arrived') {
        store.setRideStatus('in_progress');
      } else if (ride.status === 'in_progress') {
        store.setRideStatus('completed');
        setAutoAdvance(false);
      }
    }, 4500);

    return () => clearTimeout(timer);
  }, [autoAdvance, ride.status]);

  const handleCancelRide = () => {
    store.cancelRide(ride.id, cancelReason);
    setShowCancelModal(false);
  };

  const stages: { key: RideStatus; label: string; step: number }[] = [
    { key: 'searching', label: '1. Searching', step: 1 },
    { key: 'driver_assigned', label: '2. Assigned', step: 2 },
    { key: 'driver_arrived', label: '3. Arriving', step: 3 },
    { key: 'in_progress', label: '4. Started', step: 4 },
    { key: 'completed', label: '5. Completed', step: 5 }
  ];

  const getStageIndex = (status: RideStatus) => {
    switch (status) {
      case 'searching': return 0;
      case 'driver_assigned': return 1;
      case 'driver_arrived': return 2;
      case 'in_progress': return 3;
      case 'completed': return 4;
      default: return 0;
    }
  };

  const currentStageIndex = getStageIndex(ride.status);

  const handleNextStage = () => {
    if (currentStageIndex === 0) store.setRideStatus('driver_assigned');
    else if (currentStageIndex === 1) store.setRideStatus('driver_arrived');
    else if (currentStageIndex === 2) store.setRideStatus('in_progress');
    else if (currentStageIndex === 3) store.setRideStatus('completed');
  };

  // Searching State (Finding Driver)
  if (ride.status === 'searching') {
    return (
      <div className="flex flex-col gap-3">
        {/* Stage Testing Banner */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-orange-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Demo Stage Controller
            </span>
            <div className="flex items-center gap-2">
              <label className="text-[11px] text-slate-400 cursor-pointer flex items-center gap-1">
                <input
                  type="checkbox"
                  checked={autoAdvance}
                  onChange={(e) => setAutoAdvance(e.target.checked)}
                  className="accent-orange-500 rounded"
                />
                Auto-advance
              </label>
              <button
                type="button"
                onClick={handleNextStage}
                className="py-1 px-2.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-[11px] flex items-center gap-1 transition-colors"
              >
                <span>Next Stage</span>
                <FastForward className="w-3 h-3" />
              </button>
            </div>
          </div>
          <div className="grid grid-cols-5 gap-1 text-[10px] text-center font-mono font-semibold">
            {stages.map((st, i) => (
              <button
                key={st.key}
                type="button"
                onClick={() => store.setRideStatus(st.key)}
                className={`py-1 px-1 rounded truncate transition-all ${
                  i === currentStageIndex
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>

        {/* Searching Card */}
        <div className="rounded-2xl border border-orange-500/30 bg-slate-900/95 p-5 shadow-2xl backdrop-blur-md">
          <div className="flex flex-col items-center text-center py-2">
            <div className="relative mb-4 flex items-center justify-center">
              <div className="absolute h-20 w-20 rounded-full bg-orange-500/20 animate-ping" />
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-orange-500/20 border-2 border-orange-500 text-orange-400">
                {ride.vehicleCategory === 'bike' ? (
                  <Bike className="h-7 w-7 animate-pulse" />
                ) : (
                  <Car className="h-7 w-7 animate-pulse" />
                )}
              </div>
            </div>
            <h3 className="text-base font-bold text-white mb-1">
              Searching for Nearby Driver...
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mb-3">
              Locating approved {ride.vehicleCategory === 'bike' ? 'Bike Taxi' : ride.vehicleCategory === 'auto' ? 'Auto Rickshaws' : 'Cabs'} in {ride.pickup.city}...
            </p>

            <div className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs mb-4">
              <div className="text-left min-w-0">
                <span className="text-[10px] text-slate-500 block">Pickup Hub</span>
                <span className="font-semibold text-slate-200 truncate block">{ride.pickup.name}</span>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] text-slate-500 block">50% Subsidized Fare</span>
                <span className="font-bold text-orange-400 font-mono text-sm">₹{ride.customerPayableFare}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 w-full">
              <button
                type="button"
                onClick={() => setShowCancelModal(true)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancel Request
              </button>
              <button
                type="button"
                onClick={() => store.setRideStatus('driver_assigned')}
                className="flex-1 py-2.5 px-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold shadow-md transition-colors"
              >
                Simulate Driver Accept
              </button>
            </div>
          </div>
        </div>

        {/* Cancellation Modal */}
        {showCancelModal && renderCancelModal()}
      </div>
    );
  }

  function renderCancelModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
        <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
          <div className="flex items-center gap-2 mb-3 text-rose-400">
            <AlertTriangle className="h-5 w-5" />
            <h3 className="text-sm font-bold text-white">Cancel Ride Booking?</h3>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            Please choose a reason for cancellation:
          </p>
          <div className="flex flex-col gap-2 mb-4">
            {[
              'Change of plans',
              'Driver is taking too long',
              'Booked wrong vehicle type',
              'Found alternate ride',
              'Driver asked to cancel'
            ].map((reason) => (
              <label
                key={reason}
                className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer text-xs text-slate-300 hover:border-slate-700"
              >
                <input
                  type="radio"
                  name="cancelReason"
                  value={reason}
                  checked={cancelReason === reason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  className="accent-orange-500"
                />
                <span>{reason}</span>
              </label>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowCancelModal(false)}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Keep Ride
            </button>
            <button
              type="button"
              onClick={handleCancelRide}
              className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
            >
              Confirm Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Demo Booking Stage Stepper Controller (Prompt Requirement: Allow testing stages without a real driver) */}
      <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs flex flex-col gap-2 shadow-lg">
        <div className="flex items-center justify-between">
          <span className="font-bold text-orange-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Demo Stage Switcher
          </span>
          <div className="flex items-center gap-2">
            <label className="text-[11px] text-slate-400 cursor-pointer flex items-center gap-1">
              <input
                type="checkbox"
                checked={autoAdvance}
                onChange={(e) => setAutoAdvance(e.target.checked)}
                className="accent-orange-500 rounded"
              />
              Auto-advance
            </label>
            {ride.status !== 'completed' && (
              <button
                type="button"
                onClick={handleNextStage}
                className="py-1 px-2.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-[11px] flex items-center gap-1 transition-colors"
              >
                <span>Advance Stage</span>
                <FastForward className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
        <div className="grid grid-cols-5 gap-1 text-[10px] text-center font-mono font-semibold">
          {stages.map((st, i) => (
            <button
              key={st.key}
              type="button"
              onClick={() => store.setRideStatus(st.key)}
              className={`py-1.5 px-1 rounded transition-all truncate ${
                i === currentStageIndex
                  ? 'bg-orange-500 text-white font-bold ring-1 ring-orange-400'
                  : i < currentStageIndex
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                  : 'bg-slate-950 text-slate-400 hover:text-white'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Live Ride Status Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-4 shadow-xl backdrop-blur-md">
        {/* Status Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`flex h-2.5 w-2.5 rounded-full ${
                ride.status === 'in_progress'
                  ? 'bg-emerald-400 animate-pulse'
                  : ride.status === 'driver_arrived'
                  ? 'bg-amber-400 animate-pulse'
                  : ride.status === 'completed'
                  ? 'bg-emerald-500'
                  : 'bg-orange-400'
              }`}
            />
            <span className="text-sm font-bold text-white">
              {ride.status === 'driver_assigned' && 'Driver Assigned · On the Way'}
              {ride.status === 'driver_arrived' && 'Driver Arrived at Pickup!'}
              {ride.status === 'in_progress' && 'Ride in Progress · Enjoy Journey'}
              {ride.status === 'completed' && 'Ride Completed · Thank You!'}
            </span>
          </div>

          <span className="text-xs font-mono text-slate-400 font-semibold">
            Ride ID: {ride.bookingRef}
          </span>
        </div>

        {/* Start OTP Highlight Banner */}
        {ride.status !== 'in_progress' && ride.status !== 'completed' && (
          <div className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-orange-500/15 via-amber-500/15 to-orange-500/15 border border-orange-500/40 mb-3 shadow-inner">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-500 text-white shadow">
                <KeyRound className="h-4 w-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-orange-400 block tracking-wide">
                  Trip Start OTP
                </span>
                <span className="text-[11px] text-slate-300">Share with driver to start journey</span>
              </div>
            </div>
            <div className="px-3.5 py-1.5 rounded-lg bg-slate-950 border border-orange-500/50">
              <span className="font-mono text-xl font-black tracking-widest text-orange-400">
                {ride.startOtp}
              </span>
            </div>
          </div>
        )}

        {/* Driver & Vehicle Information */}
        <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800 mb-3">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={ride.driverPhotoUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'}
              alt={ride.driverName}
              referrerPolicy="no-referrer"
              className="h-12 w-12 rounded-xl object-cover border border-slate-700 shadow shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="text-sm font-bold text-white truncate">{ride.driverName || 'Driver Partner'}</h4>
                <div className="flex items-center gap-0.5 text-amber-400 text-xs font-semibold shrink-0">
                  <Star className="w-3 h-3 fill-current" />
                  <span>{ride.driverRating?.toFixed(1) || '4.9'}</span>
                </div>
              </div>
              <p className="text-xs text-slate-300 font-medium truncate">
                {ride.vehicleModel || (ride.vehicleCategory === 'bike' ? 'Hero Splendor Plus' : ride.vehicleCategory === 'auto' ? 'Bajaj RE Auto' : 'Maruti Dzire')}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[11px] font-mono font-bold text-orange-400">
                  {ride.vehicleNumber || 'OD-02-AX-1001'}
                </div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">
                  {ride.vehicleCategory === 'bike' ? 'Bike Taxi' : ride.vehicleCategory === 'auto' ? 'Auto 3W' : 'Cab 4W'}
                </span>
              </div>
            </div>
          </div>

          {/* Masked Call Button */}
          <button
            type="button"
            onClick={() => setShowCallModal(true)}
            title="Call Driver"
            className="flex flex-col items-center justify-center h-11 w-11 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 transition-colors shrink-0"
          >
            <Phone className="w-5 h-5" />
            <span className="text-[9px] mt-0.5 font-medium">Call</span>
          </button>
        </div>

        {/* Route Details */}
        <div className="flex flex-col gap-2 py-2 border-t border-slate-800 text-xs text-slate-300">
          <div className="flex items-start gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
            <div className="min-w-0 flex-1">
              <span className="text-[10px] text-slate-500 block">Pickup</span>
              <p className="truncate font-medium">{ride.pickup.name}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0" />
            <div className="min-w-0 flex-1">
              <span className="text-[10px] text-slate-500 block">Destination</span>
              <p className="truncate font-medium">{ride.destination.name}</p>
            </div>
          </div>
        </div>

        {/* Fare and Action Buttons */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 block">
              Subsidized Payable Fare ({ride.paymentMethod === 'upi_qr' ? 'UPI' : 'Cash'})
            </span>
            <span className="text-lg font-bold text-orange-400 font-mono tabular-nums">
              ₹{ride.customerPayableFare}
            </span>
            <span className="text-[10px] text-emerald-400 ml-1.5 font-semibold">
              (50% Subsidy Applied)
            </span>
          </div>

          <div className="flex items-center gap-2">
            {ride.status === 'completed' ? (
              <div className="flex items-center gap-2">
                {onOpenRating && (
                  <button
                    type="button"
                    onClick={onOpenRating}
                    className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1"
                  >
                    <Star className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                    <span>{ride.ratingByCustomer ? `${ride.ratingByCustomer}★ Rated` : 'Rate Driver'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={onOpenPayment}
                  className="py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 text-white font-bold text-xs shadow-lg shadow-orange-500/20 hover:from-orange-600 hover:to-amber-700 transition-all"
                >
                  {ride.paymentStatus === 'completed' ? 'Receipt' : `Pay ₹${ride.customerPayableFare}`}
                </button>
              </div>
            ) : (
              <>
                <button
                  type="button"
                  onClick={onOpenSupport}
                  title="Safety & Emergency SOS"
                  className="flex items-center gap-1 py-2 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-colors"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>SOS</span>
                </button>

                {/* Cancel is allowed prior to ride starting */}
                {ride.status !== 'in_progress' && (
                  <button
                    type="button"
                    onClick={() => setShowCancelModal(true)}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                  >
                    Cancel
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Masked Call Simulation Modal */}
      {showCallModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-center">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
              <Phone className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">
              Calling {ride.driverName}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              ODISHA RIDE Masked Calling: Customer phone number is confidential and never shown to drivers.
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-400 mb-4">
              Connecting via Odisha Virtual Gateway (+91 674-291-0000)
            </div>
            <button
              type="button"
              onClick={() => setShowCallModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              End Call
            </button>
          </div>
        </div>
      )}

      {/* Cancel Modal */}
      {showCancelModal && renderCancelModal()}
    </div>
  );
};
