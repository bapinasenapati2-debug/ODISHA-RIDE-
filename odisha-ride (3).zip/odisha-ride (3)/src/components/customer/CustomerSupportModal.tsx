import React, { useState } from 'react';
import { Language, SupportTicket } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import { ShieldAlert, PhoneCall, HelpCircle, FileText, Send, CheckCircle2, X } from 'lucide-react';

interface CustomerSupportModalProps {
  language: Language;
  onClose: () => void;
}

export const CustomerSupportModal: React.FC<CustomerSupportModalProps> = ({
  language,
  onClose
}) => {
  const t = getTranslation(language);
  const [tab, setTab] = useState<'sos' | 'ticket' | 'faq'>('sos');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !message) return;

    store.submitSupportTicket({
      userType: 'customer',
      userId: store.getState().customer.id,
      userName: store.getState().customer.name,
      subject,
      message
    });
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-slate-100 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/20 text-rose-400">
              <ShieldAlert className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Odisha Safety & Support</h3>
              <p className="text-[10px] text-slate-400">24x7 Assistance & Police Helpline</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 mb-4">
          <button
            type="button"
            onClick={() => setTab('sos')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              tab === 'sos' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Emergency SOS
          </button>
          <button
            type="button"
            onClick={() => setTab('ticket')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              tab === 'ticket' ? 'bg-orange-500 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Raise Ticket
          </button>
          <button
            type="button"
            onClick={() => setTab('faq')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              tab === 'faq' ? 'bg-slate-800 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Policies
          </button>
        </div>

        {tab === 'sos' && (
          <div className="flex flex-col gap-3">
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300">
              <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                Odisha Emergency SOS (Dial 112)
              </h4>
              <p className="text-xs text-rose-200/80 leading-relaxed mb-3">
                In case of immediate threat, medical emergency, or driver misconduct in Bhubaneswar / Cuttack, connect directly to Odisha Police Emergency Response.
              </p>
              <a
                href="tel:112"
                className="w-full py-2.5 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-colors"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call Odisha Police (112)</span>
              </a>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
              <h5 className="font-bold text-white mb-1">Emergency Contacts & Live Journey Share</h5>
              <p className="text-slate-400 text-[11px] mb-2">
                Your live GPS coordinates and driver vehicle details are shared with your configured emergency contact:
              </p>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 font-mono text-orange-400 text-[11px]">
                Registered Emergency Mobile: +91 9437012345
              </div>
            </div>
          </div>
        )}

        {tab === 'ticket' && (
          <div>
            {!submitted ? (
              <form onSubmit={handleTicketSubmit} className="flex flex-col gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Subject</label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Lost item, billing discrepancy, route feedback"
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-orange-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Message Description</label>
                  <textarea
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Please explain the issue in detail..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-orange-500 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Ticket</span>
                </button>
              </form>
            ) : (
              <div className="flex flex-col items-center p-5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mb-2" />
                <h4 className="text-sm font-bold text-white mb-1">Ticket Submitted Successfully</h4>
                <p className="text-xs text-slate-400 mb-4">
                  Our Odisha Ride operations team in Bhubaneswar will review your complaint within 2 hours.
                </p>
                <button
                  type="button"
                  onClick={() => setSubmitted(false)}
                  className="text-xs text-orange-400 hover:underline"
                >
                  Submit another inquiry
                </button>
              </div>
            )}
          </div>
        )}

        {tab === 'faq' && (
          <div className="flex flex-col gap-2.5 max-h-72 overflow-y-auto pr-1 text-xs text-slate-300">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <h5 className="font-bold text-white mb-1">50% Customer Subsidy Policy</h5>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                ODISHA RIDE covers 50% of the government-approved fare for the first 6 months from launch. Drivers receive 100% of the approved fare without any deduction from their approved earnings.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <h5 className="font-bold text-white mb-1">Cancellation & Fee Guidelines</h5>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Rides cancelled within 3 minutes of driver assignment have zero cancellation fee. Repeated cancellations after driver arrival may incur a nominal ₹15 fee credited to the driver.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <h5 className="font-bold text-white mb-1">Bhubaneswar & Cuttack Service Area</h5>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Seamless point-to-point transit across all Twin City areas including NH16 corridor, Biju Patnaik Airport, KIIT, SCB Medical, and Badambadi.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
