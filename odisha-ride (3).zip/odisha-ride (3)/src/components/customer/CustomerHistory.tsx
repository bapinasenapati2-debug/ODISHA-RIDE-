import React, { useState } from 'react';
import { RideBooking, Language } from '../../types';
import { getTranslation } from '../../services/i18n';
import { Car, Clock, MapPin, Navigation, Star, Receipt, CheckCircle2 } from 'lucide-react';
import { PaymentModal } from './PaymentModal';
import { PostRideRatingModal } from './PostRideRatingModal';

interface CustomerHistoryProps {
  rides: RideBooking[];
  language: Language;
}

export const CustomerHistory: React.FC<CustomerHistoryProps> = ({
  rides,
  language
}) => {
  const t = getTranslation(language);
  const [selectedReceiptRide, setSelectedReceiptRide] = useState<RideBooking | null>(null);
  const [selectedRatingRide, setSelectedRatingRide] = useState<RideBooking | null>(null);

  if (rides.length === 0) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-8 text-center text-slate-400">
        <Car className="mx-auto h-10 w-10 text-slate-600 mb-2" />
        <h4 className="text-sm font-semibold text-slate-200">No past rides yet</h4>
        <p className="text-xs text-slate-500 mt-1">
          Your completed and cancelled rides in Bhubaneswar & Cuttack will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-sm font-bold text-white px-1">
        Ride History & Official Receipts ({rides.length})
      </h3>

      <div className="flex flex-col gap-2.5">
        {rides.map((ride) => (
          <div
            key={ride.id}
            className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 shadow-md transition-all hover:border-slate-700"
          >
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-800 mb-2.5">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                    ride.status === 'completed'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}
                >
                  {ride.status}
                </span>
                <span className="text-xs font-mono font-semibold text-slate-300">
                  {ride.bookingRef}
                </span>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">
                {new Date(ride.createdAt).toLocaleDateString()}
              </span>
            </div>

            {/* Ride Route */}
            <div className="flex flex-col gap-1.5 text-xs text-slate-300 mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                <span className="truncate">{ride.pickup.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                <span className="truncate">{ride.destination.name}</span>
              </div>
            </div>

            {/* Rating Section if available */}
            {ride.ratingByCustomer ? (
              <div className="mb-2.5 p-2 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="flex items-center text-amber-400 font-bold">
                    <Star className="w-3.5 h-3.5 fill-current mr-0.5" />
                    <span>{ride.ratingByCustomer}.0</span>
                  </div>
                  <span className="text-[11px] text-slate-400 truncate max-w-[200px]">
                    {ride.reviewByCustomer || 'Rated'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedRatingRide(ride)}
                  className="text-[10px] text-orange-400 hover:underline font-semibold"
                >
                  Edit Rating
                </button>
              </div>
            ) : ride.status === 'completed' ? (
              <div className="mb-2.5 flex items-center justify-between p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs">
                <span className="text-amber-300 text-[11px] font-medium">How was your driver?</span>
                <button
                  type="button"
                  onClick={() => setSelectedRatingRide(ride)}
                  className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-colors"
                >
                  <Star className="w-3 h-3 fill-slate-950 text-slate-950" />
                  <span>Rate Driver</span>
                </button>
              </div>
            ) : null}

            {/* Metrics & Fare */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
              <div className="flex flex-col gap-0.5">
                <div className="flex items-center gap-2 text-slate-400">
                  <span className="font-semibold text-slate-200">
                    {ride.vehicleCategory === 'bike' ? 'Bike Taxi' : ride.vehicleCategory === 'auto' ? 'Auto Rickshaw' : 'Cab Taxi'}
                  </span>
                  <span>·</span>
                  <span className="font-mono">{ride.distanceKm} km</span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                  <span>Pay: {ride.paymentMethod === 'upi_qr' ? 'UPI' : 'Cash'}</span>
                  <span>•</span>
                  <span className={`font-medium ${ride.paymentStatus === 'completed' ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {ride.paymentStatus.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">Subsidized Fare</span>
                  <span className="font-bold text-orange-400 font-mono text-sm">
                    ₹{ride.customerPayableFare}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedReceiptRide(ride)}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                  title="View Receipt"
                >
                  <Receipt className="w-4 h-4 text-orange-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedReceiptRide && (
        <PaymentModal
          ride={selectedReceiptRide}
          language={language}
          onClose={() => setSelectedReceiptRide(null)}
        />
      )}

      {selectedRatingRide && (
        <PostRideRatingModal
          ride={selectedRatingRide}
          language={language}
          onClose={() => setSelectedRatingRide(null)}
        />
      )}
    </div>
  );
};
