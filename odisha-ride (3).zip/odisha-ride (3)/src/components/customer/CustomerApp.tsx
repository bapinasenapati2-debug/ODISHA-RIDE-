import React, { useState } from 'react';
import { AppState, store } from '../../services/store';
import { LocationPoint, RideBooking } from '../../types';
import { INITIAL_LOCATIONS } from '../../data/mockData';
import { MapDisplay } from '../common/MapDisplay';
import { RideBookingCard } from './RideBookingCard';
import { LiveRideTracker } from './LiveRideTracker';
import { PaymentModal } from './PaymentModal';
import { CustomerHistory } from './CustomerHistory';
import { CustomerSupportModal } from './CustomerSupportModal';
import { PostRideRatingModal } from './PostRideRatingModal';
import { getTranslation } from '../../services/i18n';
import {
  Compass,
  History,
  Shield,
  User,
  Car,
  Sparkles,
  Phone,
  CheckCircle2,
  Lock,
  LogOut,
  MapPin,
  Plus,
  Trash2,
  AlertTriangle,
  ArrowRight,
  KeyRound,
  Bike
} from 'lucide-react';

interface CustomerAppProps {
  appState: AppState;
}

export const CustomerApp: React.FC<CustomerAppProps> = ({ appState }) => {
  const t = getTranslation(appState.language);

  const [activeTab, setActiveTab] = useState<'book' | 'history' | 'profile'>('book');
  const [pickup, setPickup] = useState<LocationPoint | null>(appState.customer.savedPlaces?.home || INITIAL_LOCATIONS[0]);
  const [destination, setDestination] = useState<LocationPoint | null>(appState.customer.savedPlaces?.work || INITIAL_LOCATIONS[2]);
  const [selectionMode, setSelectionMode] = useState<'pickup' | 'destination' | null>(null);

  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [showSosAlertModal, setShowSosAlertModal] = useState(false);
  const [selectedRatingRide, setSelectedRatingRide] = useState<RideBooking | null>(null);
  const [dismissedRatingRideId, setDismissedRatingRideId] = useState<string | null>(null);

  // Auth state (Mobile login + OTP)
  const [loginPhone, setLoginPhone] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginOtp, setLoginOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // New Saved Location form
  const [showAddPlace, setShowAddPlace] = useState(false);
  const [newPlaceName, setNewPlaceName] = useState('');
  const [newPlaceAddress, setNewPlaceAddress] = useState('');
  const [newPlaceCity, setNewPlaceCity] = useState<'Bhubaneswar' | 'Cuttack'>('Bhubaneswar');

  const customer = appState.customer;
  const isLoggedIn = customer.isLoggedIn !== false; // defaults to true for initial ease
  const activeRide = appState.activeRide;
  const assignedDriver = activeRide?.driverId
    ? appState.drivers.find((d) => d.id === activeRide.driverId) || null
    : null;

  // Total rides count
  const totalRidesCount = appState.rideHistory.filter(
    (r) => r.customerId === customer.id || r.customerPhone === customer.phone
  ).length;

  const handleLocationSelect = (point: LocationPoint, type: 'pickup' | 'destination') => {
    if (type === 'pickup') {
      setPickup(point);
    } else {
      setDestination(point);
    }
    setSelectionMode(null);
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginPhone.length < 10) {
      setAuthError('Please enter a valid 10-digit mobile number.');
      return;
    }
    setAuthError(null);
    setOtpSent(true);
    setLoginOtp('123456'); // auto-fill demo OTP
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginOtp.length < 4) {
      setAuthError('Please enter the OTP received.');
      return;
    }
    store.loginCustomer(loginPhone, loginName || 'Bapina Senapati');
    setOtpSent(false);
    setAuthError(null);
  };

  const handleQuickDemoLogin = () => {
    store.loginCustomer('9861099887', 'Bapina Senapati');
  };

  const handleAddSavedPlace = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaceName.trim()) return;
    const newLoc: LocationPoint = {
      name: newPlaceName.trim(),
      address: newPlaceAddress.trim() || `${newPlaceName.trim()}, ${newPlaceCity}`,
      lat: newPlaceCity === 'Bhubaneswar' ? 20.2961 : 20.4625,
      lng: newPlaceCity === 'Bhubaneswar' ? 85.8245 : 85.8828,
      city: newPlaceCity
    };
    store.addSavedPlace(newLoc);
    setNewPlaceName('');
    setNewPlaceAddress('');
    setShowAddPlace(false);
  };

  // If customer is logged out, render Customer Login Screen
  if (!isLoggedIn) {
    return (
      <div className="flex flex-col min-h-[calc(100vh-4rem)] max-w-lg mx-auto p-4 sm:p-6 justify-center">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          {/* Logo & Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-lg shadow-orange-500/30 mb-3">
              <Car className="h-7 w-7" />
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              ODISHA <span className="text-orange-500">RIDE</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Customer Ride Booking · Bhubaneswar & Cuttack
            </p>
          </div>

          {/* 50% Subsidy Callout */}
          <div className="p-3 rounded-2xl bg-orange-500/10 border border-orange-500/30 mb-6 flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-orange-400 shrink-0" />
            <div className="text-left text-xs">
              <span className="font-bold text-orange-300 block">50% Odisha Customer Subsidy Active</span>
              <span className="text-slate-400 text-[11px]">Pay only half price on Auto, Bike & Cab rides!</span>
            </div>
          </div>

          {!otpSent ? (
            <form onSubmit={handleSendOtp} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Full Name (Optional)
                </label>
                <input
                  type="text"
                  value={loginName}
                  onChange={(e) => setLoginName(e.target.value)}
                  placeholder="e.g. Bapina Senapati"
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-600 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Mobile Number
                </label>
                <div className="flex items-center rounded-xl bg-slate-950 border border-slate-800 p-2.5 focus-within:border-orange-500">
                  <span className="text-xs font-mono font-bold text-orange-400 mr-2">+91</span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={loginPhone}
                    onChange={(e) => setLoginPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="98610XXXXX"
                    className="bg-transparent text-sm text-white placeholder-slate-600 focus:outline-none flex-1 font-mono tracking-wider"
                  />
                </div>
              </div>

              {authError && (
                <p className="text-xs text-rose-400 font-medium">{authError}</p>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
              >
                <span>SEND DEMO OTP</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-800" />
                <span className="flex-shrink mx-3 text-[10px] text-slate-500 uppercase font-mono">OR</span>
                <div className="flex-grow border-t border-slate-800" />
              </div>

              <button
                type="button"
                onClick={handleQuickDemoLogin}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
              >
                Instant One-Click Login (Demo Account)
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="flex flex-col gap-4">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-center">
                <span className="text-slate-400 block">OTP Sent to Mobile:</span>
                <span className="font-mono text-sm font-bold text-orange-400">+91 {loginPhone}</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 text-center">
                  Enter 6-Digit Demo OTP
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={loginOtp}
                  onChange={(e) => setLoginOtp(e.target.value)}
                  placeholder="123456"
                  className="w-full p-3 text-center font-mono text-2xl tracking-[0.4em] rounded-xl bg-slate-950 border border-orange-500/50 text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              {authError && (
                <p className="text-xs text-rose-400 font-medium text-center">{authError}</p>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg shadow-orange-500/25 transition-all"
              >
                VERIFY & ENTER ODISHA RIDE
              </button>

              <div className="flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => setOtpSent(false)}
                  className="hover:text-white"
                >
                  Change Mobile
                </button>
                <button
                  type="button"
                  onClick={() => setLoginOtp('123456')}
                  className="text-orange-400 hover:underline"
                >
                  Fill Demo OTP 123456
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)] max-w-5xl mx-auto p-3 sm:p-5 gap-4">
      {/* 50% Subsidy Top Banner */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-orange-500/20 via-amber-500/20 to-orange-500/20 border border-orange-500/40 shadow-lg">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-orange-500 text-white shadow-md">
            <Sparkles className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs sm:text-sm font-extrabold text-white truncate">
              {t.odishaSubsidy} (First 6 Months Active)
            </h4>
            <p className="text-[11px] text-orange-200/90 hidden sm:block truncate">
              Enjoy 50% discount on Auto, Bike & Cab rides in Bhubaneswar & Cuttack. Drivers receive full 100% fare.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowSosAlertModal(true)}
            className="flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-colors"
          >
            <Shield className="w-3.5 h-3.5 text-rose-400" />
            <span>Safety SOS</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Interactive Map + Booking / Tracker Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Interactive Google Map / Vector Fallback */}
        <div className="lg:col-span-7 flex flex-col gap-3">
          <MapDisplay
            pickup={activeRide ? activeRide.pickup : pickup}
            destination={activeRide ? activeRide.destination : destination}
            activeDriver={assignedDriver}
            nearbyDrivers={appState.drivers}
            selectionMode={selectionMode}
            onSelectLocation={handleLocationSelect}
            className="h-[360px] sm:h-[420px] w-full"
          />

          {/* Quick Hub Buttons */}
          <div className="p-3 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur-sm flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-semibold text-slate-400 mr-1">
              Odisha Hubs:
            </span>
            <button
              type="button"
              onClick={() => {
                setPickup(INITIAL_LOCATIONS[0]);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
            >
              Master Canteen (BBSR)
            </button>
            <button
              type="button"
              onClick={() => {
                setDestination(INITIAL_LOCATIONS[1]);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
            >
              Airport BBI
            </button>
            <button
              type="button"
              onClick={() => {
                setDestination(INITIAL_LOCATIONS[2]);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
            >
              KIIT Patia
            </button>
            <button
              type="button"
              onClick={() => {
                setPickup(INITIAL_LOCATIONS[7]);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
            >
              Badambadi (CTC)
            </button>
          </div>
        </div>

        {/* Right Column: Dynamic Action Card (Booking vs Live Tracker vs History vs Profile) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Top Segmented Navigation Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-2xl border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('book')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'book'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>{activeRide ? 'Active Ride' : 'Book Ride'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>History ({totalRidesCount})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'profile'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Profile</span>
            </button>
          </div>

          {/* Tab 1: Book / Active Trip Tracker */}
          {activeTab === 'book' && (
            <div>
              {activeRide ? (
                <LiveRideTracker
                  ride={activeRide}
                  language={appState.language}
                  onOpenPayment={() => setShowPaymentModal(true)}
                  onOpenSupport={() => setShowSupportModal(true)}
                  onOpenRating={() => setSelectedRatingRide(activeRide)}
                />
              ) : (
                <RideBookingCard
                  appState={appState}
                  pickup={pickup}
                  destination={destination}
                  onSetPickup={setPickup}
                  onSetDestination={setDestination}
                  selectionMode={selectionMode}
                  onSelectMapMode={setSelectionMode}
                  language={appState.language}
                />
              )}
            </div>
          )}

          {/* Tab 2: Ride History & Past Receipts */}
          {activeTab === 'history' && (
            <CustomerHistory rides={appState.rideHistory} language={appState.language} />
          )}

          {/* Tab 3: Customer Profile & Settings */}
          {activeTab === 'profile' && (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-5 shadow-xl flex flex-col gap-4">
              {/* Profile Card Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 text-white font-bold text-lg shadow-md">
                    {customer.name.slice(0, 1)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{customer.name}</h4>
                    <p className="text-xs text-slate-400 font-mono">+91 {customer.phone}</p>
                    <p className="text-[11px] text-slate-500">{customer.email || 'customer@odisharide.in'}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Trips</span>
                  <span className="text-base font-black text-orange-400 font-mono">{totalRidesCount}</span>
                </div>
              </div>

              {/* Saved Locations Manager */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-orange-400" />
                    Saved Favorite Places
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAddPlace(!showAddPlace)}
                    className="text-xs text-orange-400 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Place</span>
                  </button>
                </div>

                {/* Add Place Drawer */}
                {showAddPlace && (
                  <form onSubmit={handleAddSavedPlace} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2 text-xs">
                    <input
                      type="text"
                      required
                      value={newPlaceName}
                      onChange={(e) => setNewPlaceName(e.target.value)}
                      placeholder="Place Name (e.g. AIIMS Hospital, Gym)"
                      className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-white"
                    />
                    <input
                      type="text"
                      value={newPlaceAddress}
                      onChange={(e) => setNewPlaceAddress(e.target.value)}
                      placeholder="Address or Landmark"
                      className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-white"
                    />
                    <div className="flex items-center gap-2">
                      <select
                        value={newPlaceCity}
                        onChange={(e) => setNewPlaceCity(e.target.value as any)}
                        className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-white flex-1"
                      >
                        <option value="Bhubaneswar">Bhubaneswar</option>
                        <option value="Cuttack">Cuttack</option>
                      </select>
                      <button
                        type="submit"
                        className="py-2 px-3 rounded-lg bg-orange-500 text-white font-bold"
                      >
                        Save
                      </button>
                    </div>
                  </form>
                )}

                {/* Home & Work */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      if (customer.savedPlaces?.home) setPickup(customer.savedPlaces.home);
                      setActiveTab('book');
                    }}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-orange-500/50 text-left transition-colors"
                  >
                    <span className="text-[10px] text-slate-500 block uppercase font-bold">Home</span>
                    <p className="font-semibold text-slate-200 truncate">
                      {customer.savedPlaces?.home?.name || 'Master Canteen'}
                    </p>
                    <span className="text-[10px] text-orange-400 mt-1 block">Click to set Pickup</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (customer.savedPlaces?.work) setDestination(customer.savedPlaces.work);
                      setActiveTab('book');
                    }}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-orange-500/50 text-left transition-colors"
                  >
                    <span className="text-[10px] text-slate-500 block uppercase font-bold">Work</span>
                    <p className="font-semibold text-slate-200 truncate">
                      {customer.savedPlaces?.work?.name || 'KIIT Square Patia'}
                    </p>
                    <span className="text-[10px] text-orange-400 mt-1 block">Click to set Drop</span>
                  </button>
                </div>

                {/* Custom Saved Places */}
                {customer.savedPlaces?.other && customer.savedPlaces.other.length > 0 && (
                  <div className="flex flex-col gap-1.5 mt-1">
                    {customer.savedPlaces.other.map((place, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs"
                      >
                        <div
                          className="min-w-0 cursor-pointer flex-1"
                          onClick={() => {
                            setDestination(place);
                            setActiveTab('book');
                          }}
                        >
                          <p className="font-semibold text-slate-200 truncate">{place.name}</p>
                          <p className="text-[10px] text-slate-500 truncate">{place.city} · {place.address}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => store.removeSavedPlace(idx)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Safety SOS Configuration */}
              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex flex-col gap-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-rose-300 flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-rose-400" />
                    Safety & Emergency SOS
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowSosAlertModal(true)}
                    className="py-1 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] shadow transition-colors"
                  >
                    Test SOS Alert
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Emergency Contact Number</label>
                  <input
                    type="tel"
                    defaultValue={customer.emergencyContact || '9437012345'}
                    onBlur={(e) => store.updateCustomerProfile({ emergencyContact: e.target.value })}
                    className="w-full bg-slate-950 p-2 rounded-lg border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Help & Support Button */}
              <button
                type="button"
                onClick={() => setShowSupportModal(true)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <span>Help, Grievances & 24x7 Support</span>
              </button>

              {/* Logout Button */}
              <button
                type="button"
                onClick={() => store.logoutCustomer()}
                className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-rose-950/40 text-rose-400 border border-slate-800 hover:border-rose-500/40 font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out of Odisha Ride</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Payment & Receipt Modal */}
      {showPaymentModal && activeRide && (
        <PaymentModal
          ride={activeRide}
          language={appState.language}
          onClose={() => setShowPaymentModal(false)}
        />
      )}

      {/* Post-Ride Rating Screen */}
      {(selectedRatingRide || (activeRide && activeRide.status === 'completed' && !activeRide.ratingByCustomer && dismissedRatingRideId !== activeRide.id)) && (
        <PostRideRatingModal
          ride={selectedRatingRide || activeRide!}
          language={appState.language}
          onClose={() => {
            const closingId = selectedRatingRide?.id || activeRide?.id;
            if (closingId) {
              setDismissedRatingRideId(closingId);
            }
            setSelectedRatingRide(null);
          }}
        />
      )}

      {/* Safety & Support Modal */}
      {showSupportModal && (
        <CustomerSupportModal
          language={appState.language}
          onClose={() => setShowSupportModal(false)}
        />
      )}

      {/* Simulated Emergency SOS Alert Modal */}
      {showSosAlertModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-rose-500/50 p-5 shadow-2xl text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-rose-500/20 text-rose-400">
              <Shield className="h-7 w-7" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">
              Safety SOS Alert Dispatched!
            </h3>
            <p className="text-xs text-slate-300 mb-3">
              Your real-time GPS coordinates have been securely shared with:
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-left mb-4 flex flex-col gap-1">
              <p className="text-rose-400 font-bold">1. Odisha Police ERSS (Dial 112)</p>
              <p className="text-slate-300">2. Emergency Contact: +91 {customer.emergencyContact || '9437012345'}</p>
              <p className="text-slate-400 text-[10px]">3. 24x7 Odisha Ride Safety Operations Room</p>
            </div>
            <button
              type="button"
              onClick={() => setShowSosAlertModal(false)}
              className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs"
            >
              Dismiss Alert
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
