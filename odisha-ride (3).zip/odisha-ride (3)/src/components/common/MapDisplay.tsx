import React, { useEffect, useRef, useState } from 'react';
import { APIProvider, Map, AdvancedMarker, useMap } from '@vis.gl/react-google-maps';
import { LocationPoint, DriverUser, VehicleCategory } from '../../types';
import { Compass, Crosshair, MapPin, Navigation, Car, AlertTriangle } from 'lucide-react';

interface MapDisplayProps {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeDriver?: DriverUser | null;
  nearbyDrivers?: DriverUser[];
  onSelectLocation?: (point: LocationPoint, type: 'pickup' | 'destination') => void;
  selectionMode?: 'pickup' | 'destination' | null;
  className?: string;
  interactive?: boolean;
}

declare global {
  interface Window {
    google?: any;
  }
}

// Inner helper component to manage map camera and route polyline when using Google Maps
function MapController({
  pickup,
  destination,
  activeDriver
}: {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeDriver?: DriverUser | null;
}) {
  const map = useMap();
  const polylineRef = useRef<any>(null);

  useEffect(() => {
    if (!map) return;
    const gmaps = typeof window !== 'undefined' ? (window as any).google?.maps : null;

    // Draw route polyline if both pickup and destination exist
    if (pickup && destination && gmaps) {
      if (!polylineRef.current) {
        polylineRef.current = new gmaps.Polyline({
          strokeColor: '#ea580c', // Odisha Ride signature warm saffron
          strokeOpacity: 0.9,
          strokeWeight: 5,
          map: map
        });
      }

      const path = [
        { lat: pickup.lat, lng: pickup.lng },
        { lat: destination.lat, lng: destination.lng }
      ];
      polylineRef.current.setPath(path);

      // Fit bounds
      const bounds = new gmaps.LatLngBounds();
      bounds.extend(new gmaps.LatLng(pickup.lat, pickup.lng));
      bounds.extend(new gmaps.LatLng(destination.lat, destination.lng));
      if (activeDriver) {
        bounds.extend(new gmaps.LatLng(activeDriver.currentLocation.lat, activeDriver.currentLocation.lng));
      }
      map.fitBounds(bounds, { top: 60, right: 60, bottom: 60, left: 60 });
    } else if (pickup && gmaps) {
      map.panTo({ lat: pickup.lat, lng: pickup.lng });
      map.setZoom(15);
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
    }
  }, [map, pickup, destination, activeDriver]);

  return null;
}

export const MapDisplay: React.FC<MapDisplayProps> = ({
  pickup,
  destination,
  activeDriver,
  nearbyDrivers = [],
  onSelectLocation,
  selectionMode = null,
  className = 'h-72 w-full',
  interactive = true
}) => {
  const apiKey = (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string) || '';
  const [mapError, setMapError] = useState(false);
  const [currentGps, setCurrentGps] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [activeCity, setActiveCity] = useState<'Bhubaneswar' | 'Cuttack'>('Bhubaneswar');

  const defaultCenter = pickup
    ? { lat: pickup.lat, lng: pickup.lng }
    : activeCity === 'Bhubaneswar'
    ? { lat: 20.2961, lng: 85.8245 }
    : { lat: 20.4625, lng: 85.8828 };

  const handleGetGps = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        const pt = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCurrentGps(pt);
        if (onSelectLocation && selectionMode) {
          onSelectLocation(
            {
              name: 'My Current GPS Location',
              address: `GPS: ${pt.lat.toFixed(4)}, ${pt.lng.toFixed(4)}`,
              lat: pt.lat,
              lng: pt.lng,
              city: pt.lat > 20.38 ? 'Cuttack' : 'Bhubaneswar'
            },
            selectionMode
          );
        }
      },
      () => {
        setLocating(false);
        // Fallback to Master Canteen Bhubaneswar
        const fallback = { lat: 20.2648, lng: 85.8394 };
        setCurrentGps(fallback);
      },
      { timeout: 7000 }
    );
  };

  // If API key is available and no fatal error occurred, render Google Maps SDK with AdvancedMarker
  const renderGoogleMap = Boolean(apiKey && !mapError);

  return (
    <div className={`relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 shadow-inner ${className}`}>
      {/* Top Map Controls: City switch & GPS */}
      <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/80 shadow-lg pointer-events-auto">
          <button
            type="button"
            onClick={() => setActiveCity('Bhubaneswar')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeCity === 'Bhubaneswar'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Bhubaneswar
          </button>
          <button
            type="button"
            onClick={() => setActiveCity('Cuttack')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeCity === 'Cuttack'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Cuttack
          </button>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            onClick={handleGetGps}
            title="Use Current GPS"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-200 text-xs font-medium rounded-xl border border-slate-700/80 shadow-lg transition-colors"
          >
            <Crosshair className={`w-3.5 h-3.5 text-orange-400 ${locating ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">GPS</span>
          </button>
        </div>
      </div>

      {/* Mode hint badge */}
      {selectionMode && (
        <div className="absolute bottom-3 left-3 z-20 pointer-events-none">
          <div className="px-3 py-1.5 bg-orange-600/95 text-white text-xs font-semibold rounded-lg shadow-lg backdrop-blur-sm flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            <span>Click map to set {selectionMode === 'pickup' ? 'Pickup Point' : 'Destination'}</span>
          </div>
        </div>
      )}

      {renderGoogleMap ? (
        <APIProvider apiKey={apiKey}>
          <Map
            defaultCenter={defaultCenter}
            defaultZoom={13}
            mapId="DEMO_MAP_ID"
            className="w-full h-full min-h-[300px]"
            disableDefaultUI={false}
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            onClick={(e) => {
              if (interactive && onSelectLocation && selectionMode && e.detail.latLng) {
                const lat = e.detail.latLng.lat;
                const lng = e.detail.latLng.lng;
                onSelectLocation(
                  {
                    name: `Pinned Point (${lat.toFixed(3)}, ${lng.toFixed(3)})`,
                    address: `${lat > 20.38 ? 'Cuttack' : 'Bhubaneswar'}, Odisha`,
                    lat,
                    lng,
                    city: lat > 20.38 ? 'Cuttack' : 'Bhubaneswar'
                  },
                  selectionMode
                );
              }
            }}
          >
            <MapController pickup={pickup} destination={destination} activeDriver={activeDriver} />

            {/* Pickup Marker */}
            {pickup && (
              <AdvancedMarker position={{ lat: pickup.lat, lng: pickup.lng }}>
                <div className="flex flex-col items-center group">
                  <div className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded shadow-md whitespace-nowrap mb-1">
                    Pickup
                  </div>
                  <div className="w-8 h-8 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center shadow-lg ring-4 ring-emerald-500/20">
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                </div>
              </AdvancedMarker>
            )}

            {/* Destination Marker */}
            {destination && (
              <AdvancedMarker position={{ lat: destination.lat, lng: destination.lng }}>
                <div className="flex flex-col items-center">
                  <div className="px-2 py-0.5 bg-rose-600 text-white text-[10px] font-bold rounded shadow-md whitespace-nowrap mb-1">
                    Drop-off
                  </div>
                  <div className="w-8 h-8 rounded-full bg-rose-500 border-2 border-white flex items-center justify-center shadow-lg ring-4 ring-rose-500/20">
                    <Navigation className="w-4 h-4 text-white" />
                  </div>
                </div>
              </AdvancedMarker>
            )}

            {/* Active Driver Live Location */}
            {activeDriver && (
              <AdvancedMarker position={{ lat: activeDriver.currentLocation.lat, lng: activeDriver.currentLocation.lng }}>
                <div className="flex flex-col items-center">
                  <div className="px-2 py-0.5 bg-orange-600 text-white text-[10px] font-bold rounded shadow-md whitespace-nowrap mb-1">
                    {activeDriver.name} ({activeDriver.vehicleNumber})
                  </div>
                  <div className="w-9 h-9 rounded-full bg-orange-500 border-2 border-white flex items-center justify-center shadow-xl ring-4 ring-orange-500/30 animate-pulse">
                    <Car className="w-5 h-5 text-white" />
                  </div>
                </div>
              </AdvancedMarker>
            )}

            {/* Other Nearby Drivers */}
            {nearbyDrivers.map((driver) => (
              <AdvancedMarker
                key={driver.id}
                position={{ lat: driver.currentLocation.lat, lng: driver.currentLocation.lng }}
              >
                <div
                  className="w-7 h-7 rounded-full bg-slate-800 border border-slate-600 text-orange-400 flex items-center justify-center shadow-md hover:scale-110 transition-transform"
                  title={`${driver.name} - ${driver.vehicleModel} (${driver.vehicleCategory})`}
                >
                  <Car className="w-3.5 h-3.5" />
                </div>
              </AdvancedMarker>
            ))}
          </Map>
        </APIProvider>
      ) : (
        /* High-fidelity interactive vector canvas fallback with Bhubaneswar & Cuttack geodata */
        <InteractiveVectorMap
          pickup={pickup}
          destination={destination}
          activeDriver={activeDriver}
          nearbyDrivers={nearbyDrivers}
          activeCity={activeCity}
          onSelectLocation={onSelectLocation}
          selectionMode={selectionMode}
        />
      )}
    </div>
  );
};

/**
 * Interactive Vector Map component with styled road networks, landmarks, animated vehicles,
 * and click-to-pin location handling for Bhubaneswar and Cuttack.
 */
function InteractiveVectorMap({
  pickup,
  destination,
  activeDriver,
  nearbyDrivers = [],
  activeCity,
  onSelectLocation,
  selectionMode
}: {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeDriver?: DriverUser | null;
  nearbyDrivers?: DriverUser[];
  activeCity: 'Bhubaneswar' | 'Cuttack';
  onSelectLocation?: (point: LocationPoint, type: 'pickup' | 'destination') => void;
  selectionMode?: 'pickup' | 'destination' | null;
}) {
  // Bounding box for mapping lat/lng to percentage coordinates
  // Bhubaneswar: lat 20.20 to 20.38, lng 85.75 to 85.90
  // Cuttack: lat 20.42 to 20.52, lng 85.80 to 85.94
  const bounds =
    activeCity === 'Bhubaneswar'
      ? { minLat: 20.21, maxLat: 20.37, minLng: 85.76, maxLng: 85.89 }
      : { minLat: 20.43, maxLat: 20.51, minLng: 85.81, maxLng: 85.93 };

  const toXY = (lat: number, lng: number) => {
    const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
    const y = (1 - (lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100;
    return {
      x: Math.max(5, Math.min(95, x)),
      y: Math.max(8, Math.min(92, y))
    };
  };

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!onSelectLocation || !selectionMode) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const xPercent = (e.clientX - rect.left) / rect.width;
    const yPercent = (e.clientY - rect.top) / rect.height;

    const lng = bounds.minLng + xPercent * (bounds.maxLng - bounds.minLng);
    const lat = bounds.maxLat - yPercent * (bounds.maxLat - bounds.minLat);

    onSelectLocation(
      {
        name: `${selectionMode === 'pickup' ? 'Pickup Point' : 'Destination'} (${lat.toFixed(3)}, ${lng.toFixed(3)})`,
        address: `${activeCity}, Odisha`,
        lat,
        lng,
        city: activeCity
      },
      selectionMode
    );
  };

  const pickupCoord = pickup ? toXY(pickup.lat, pickup.lng) : null;
  const destCoord = destination ? toXY(destination.lat, destination.lng) : null;
  const driverCoord = activeDriver ? toXY(activeDriver.currentLocation.lat, activeDriver.currentLocation.lng) : null;

  return (
    <div
      onClick={handleMapClick}
      className="relative w-full h-full min-h-[320px] bg-slate-950 cursor-crosshair select-none overflow-hidden"
    >
      {/* Odisha Map Vector Grid & Roads */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#334155" strokeWidth="0.75" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* Major NH16 Highway through Bhubaneswar & Cuttack */}
        <path d="M 10 90 Q 40 60 70 30 T 95 10" fill="none" stroke="#475569" strokeWidth="6" strokeLinecap="round" />
        <path d="M 10 90 Q 40 60 70 30 T 95 10" fill="none" stroke="#94a3b8" strokeWidth="2" strokeDasharray="6 4" />
        {/* Ring road & Arterial connections */}
        <path d="M 20 30 C 50 20, 80 50, 60 85" fill="none" stroke="#334155" strokeWidth="3" />
        <path d="M 30 75 Q 60 65 85 80" fill="none" stroke="#334155" strokeWidth="3" />
        {/* River Mahanadi (for Cuttack) or Kuakhai / Daya (for Bhubaneswar) */}
        <path d="M 0 35 Q 50 45 100 25" fill="none" stroke="#0284c7" strokeWidth="7" opacity="0.4" />
      </svg>

      {/* City Watermark */}
      <div className="absolute bottom-3 right-3 text-right pointer-events-none">
        <span className="text-[11px] font-mono tracking-widest text-slate-600 uppercase font-semibold">
          ODISHA RIDE · {activeCity.toUpperCase()} GPS
        </span>
      </div>

      {/* Active Route Line */}
      {pickupCoord && destCoord && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
          <line
            x1={`${pickupCoord.x}%`}
            y1={`${pickupCoord.y}%`}
            x2={`${destCoord.x}%`}
            y2={`${destCoord.y}%`}
            stroke="#ea580c"
            strokeWidth="4"
            strokeDasharray="8 6"
            className="animate-pulse"
          />
        </svg>
      )}

      {/* Active Driver Movement Line toward pickup */}
      {driverCoord && pickupCoord && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
          <line
            x1={`${driverCoord.x}%`}
            y1={`${driverCoord.y}%`}
            x2={`${pickupCoord.x}%`}
            y2={`${pickupCoord.y}%`}
            stroke="#38bdf8"
            strokeWidth="3"
            strokeDasharray="4 4"
          />
        </svg>
      )}

      {/* Nearby Available Drivers */}
      {nearbyDrivers
        .filter((d) => d.isOnline)
        .map((drv) => {
          const pt = toXY(drv.currentLocation.lat, drv.currentLocation.lng);
          return (
            <div
              key={drv.id}
              style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none group"
            >
              <div className="w-6 h-6 rounded-full bg-slate-800 border border-orange-500/60 text-orange-400 flex items-center justify-center shadow-lg transition-transform hover:scale-125">
                <Car className="w-3.5 h-3.5" />
              </div>
              <div className="hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-0.5 bg-slate-900 border border-slate-700 text-white text-[10px] rounded whitespace-nowrap shadow-lg">
                {drv.vehicleModel} ({drv.vehicleCategory === 'auto' ? 'Auto' : 'Cab'})
              </div>
            </div>
          );
        })}

      {/* Pickup Marker */}
      {pickupCoord && (
        <div
          style={{ left: `${pickupCoord.x}%`, top: `${pickupCoord.y}%` }}
          className="absolute -translate-x-1/2 -translate-y-full z-20 pointer-events-none"
        >
          <div className="flex flex-col items-center">
            <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded shadow-md whitespace-nowrap mb-1">
              Pickup: {pickup?.name.split('(')[0]}
            </span>
            <div className="w-7 h-7 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center shadow-lg ring-4 ring-emerald-500/30">
              <MapPin className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      )}

      {/* Destination Marker */}
      {destCoord && (
        <div
          style={{ left: `${destCoord.x}%`, top: `${destCoord.y}%` }}
          className="absolute -translate-x-1/2 -translate-y-full z-20 pointer-events-none"
        >
          <div className="flex flex-col items-center">
            <span className="px-2 py-0.5 bg-rose-600 text-white text-[10px] font-bold rounded shadow-md whitespace-nowrap mb-1">
              Drop: {destination?.name.split('(')[0]}
            </span>
            <div className="w-7 h-7 rounded-full bg-rose-500 border-2 border-white flex items-center justify-center shadow-lg ring-4 ring-rose-500/30">
              <Navigation className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      )}

      {/* Assigned Active Driver with live pulsing radar ring */}
      {driverCoord && (
        <div
          style={{ left: `${driverCoord.x}%`, top: `${driverCoord.y}%` }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none"
        >
          <div className="relative flex items-center justify-center">
            <div className="absolute w-12 h-12 rounded-full bg-orange-500/20 animate-ping" />
            <div className="w-9 h-9 rounded-full bg-orange-500 border-2 border-white flex items-center justify-center shadow-2xl ring-4 ring-orange-500/40">
              <Car className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 bg-slate-900/90 border border-orange-500/50 text-orange-200 text-[10px] font-semibold rounded whitespace-nowrap shadow-md">
            {activeDriver?.name} ({activeDriver?.vehicleNumber})
          </div>
        </div>
      )}
    </div>
  );
}
