import React from 'react';
import { Role, Language } from '../../types';
import { getTranslation } from '../../services/i18n';
import { Shield, Smartphone, CarFront, LayoutGrid, Globe, RotateCcw } from 'lucide-react';
import { store } from '../../services/store';

interface HeaderProps {
  currentRole: Role;
  splitView: boolean;
  language: Language;
  onRoleChange: (role: Role) => void;
  onSplitViewToggle: () => void;
  onLanguageChange: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  splitView,
  language,
  onRoleChange,
  onSplitViewToggle,
  onLanguageChange
}) => {
  const t = getTranslation(language);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        {/* Zone 1: Brand Wordmark with Konark Sun Temple Wheel Motif */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-lg shadow-orange-500/25 ring-1 ring-white/20">
            {/* Konark Chakra / Odisha Ride Wheel SVG */}
            <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
              <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth="2" />
              <path d="M12 3v6M12 15v6M3 12h6M15 12h6M5.6 5.6l4.2 4.2M14.2 14.2l4.2 4.2M5.6 18.4l4.2-4.2M14.2 9.8l4.2-4.2" stroke="currentColor" strokeWidth="1.5" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-display text-lg font-extrabold tracking-tight text-white whitespace-nowrap">
              ODISHA <span className="text-orange-500">RIDE</span>
            </span>
            <span className="text-[10px] font-medium tracking-wide text-slate-400 whitespace-nowrap hidden sm:inline">
              Bhubaneswar · Cuttack
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation / Role Switcher Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => onRoleChange('customer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentRole === 'customer' && !splitView
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{t.customer}</span>
          </button>

          <button
            type="button"
            onClick={() => onRoleChange('driver')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentRole === 'driver' && !splitView
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CarFront className="w-3.5 h-3.5" />
            <span>{t.driver}</span>
          </button>

          <button
            type="button"
            onClick={() => onRoleChange('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentRole === 'admin'
                ? 'bg-slate-800 text-orange-400 ring-1 ring-orange-500/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{t.admin}</span>
          </button>

          <button
            type="button"
            onClick={onSplitViewToggle}
            title="Simulate Customer and Driver side-by-side"
            className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              splitView
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>{t.dualView}</span>
          </button>
        </nav>

        {/* Zone 3: Language Selector & Reset Demo */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Language selector */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-0.5 hidden sm:inline" />
            {(['en', 'or', 'hi'] as Language[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => onLanguageChange(lang)}
                className={`px-2 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  language === lang
                    ? 'bg-orange-500/20 text-orange-400 font-bold border border-orange-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {lang === 'en' ? 'EN' : lang === 'or' ? 'ଓଡ଼ିଆ' : 'हिन्दी'}
              </button>
            ))}
          </div>

          {/* Reset Demo Data Button */}
          <button
            type="button"
            onClick={() => {
              if (confirm('Reset simulation data to initial state?')) {
                store.resetAllData();
              }
            }}
            title="Reset Simulation State"
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
