import React, { useState } from 'react';
import { AppState, store } from '../../services/store';
import { DriverApprovals } from './DriverApprovals';
import { FleetOwnershipTable } from './FleetOwnershipTable';
import { FareSubsidyManager } from './FareSubsidyManager';
import { MapDisplay } from '../common/MapDisplay';
import { getTranslation } from '../../services/i18n';
import {
  Users,
  CarFront,
  Car,
  TrendingUp,
  CreditCard,
  DollarSign,
  Download,
  ShieldCheck,
  Award,
  AlertCircle,
  Clock,
  Sparkles,
  MapPin,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';

interface AdminDashboardProps {
  appState: AppState;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ appState }) => {
  const t = getTranslation(appState.language);
  const [activeTab, setActiveTab] = useState<'overview' | 'drivers' | 'fleet' | 'fares' | 'liveMap' | 'support'>('overview');

  const { drivers, rideHistory, activeRide, fareConfig, subsidyConfig, supportTickets } = appState;

  // Driver metrics
  const totalDrivers = drivers.length;
  const approvedDrivers = drivers.filter((d) => d.isApproved).length;
  const pendingDrivers = drivers.filter((d) => d.approvalStatus === 'pending').length;
  const onlineDrivers = drivers.filter((d) => d.isOnline).length;
  const offlineDrivers = totalDrivers - onlineDrivers;

  // Fleet ownership metrics
  const ownerVehiclesCount = drivers.filter((d) => d.vehicleOwnership === 'owner_company').length;
  const friendVehiclesCount = drivers.filter((d) => d.vehicleOwnership === 'friend').length;
  const independentVehiclesCount = drivers.filter((d) => d.vehicleOwnership === 'independent').length;

  // Booking & Financial Metrics
  const allRides = activeRide ? [activeRide, ...rideHistory] : rideHistory;
  const totalBookings = allRides.length;
  const completedRides = allRides.filter((r) => r.status === 'completed');
  const cancelledRides = allRides.filter((r) => r.status === 'cancelled');

  const totalGrossRevenue = completedRides.reduce((sum, r) => sum + r.totalGrossFare, 0);
  const totalCustomerCollections = completedRides.reduce((sum, r) => sum + r.customerPayableFare, 0);
  const totalSubsidyDisbursed = completedRides.reduce((sum, r) => sum + r.companySubsidyAmount, 0);

  // External Driver Payouts (excluding owner's own vehicles which are company retained)
  const externalDriverPayouts = completedRides
    .filter((r) => r.vehicleOwnership !== 'owner_company')
    .reduce((sum, r) => sum + r.driverPayoutAmount, 0);

  const ownerVehiclesRevenueRetained = completedRides
    .filter((r) => r.vehicleOwnership === 'owner_company')
    .reduce((sum, r) => sum + r.totalGrossFare, 0);

  // Payment Breakdown
  const upiPayments = completedRides.filter((r) => r.paymentMethod === 'upi_qr').length;
  const onlinePayments = completedRides.filter((r) => r.paymentMethod === 'online').length;
  const cashPayments = completedRides.filter((r) => r.paymentMethod === 'cash').length;

  // Export Financial CSV Report
  const handleExportCSV = () => {
    const headers = [
      'Booking Ref',
      'Date',
      'Customer Name',
      'Driver Name',
      'Vehicle Number',
      'Vehicle Category',
      'Ownership',
      'Pickup City',
      'Distance (km)',
      'Gross Fare (Rs)',
      'Odisha 50% Subsidy (Rs)',
      'Customer Paid (Rs)',
      'Payment Method',
      'Payment Status',
      'Status'
    ];

    const rows = completedRides.map((r) => [
      r.bookingRef,
      new Date(r.createdAt).toISOString(),
      r.customerName,
      r.driverName || 'N/A',
      r.vehicleNumber || 'N/A',
      r.vehicleCategory,
      r.vehicleOwnership || 'independent',
      r.pickup.city,
      r.distanceKm,
      r.totalGrossFare,
      r.companySubsidyAmount,
      r.customerPayableFare,
      r.paymentMethod,
      r.paymentStatus,
      r.status
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ODISHA_RIDE_Financial_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)] max-w-7xl mx-auto p-4 sm:p-6 gap-6">
      {/* Super Admin Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-orange-500/10 text-orange-400 border border-orange-500/20 text-[11px] font-bold uppercase tracking-wider">
              Odisha Transport Authority & Super Admin
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            ODISHA RIDE Super Admin Console
          </h2>
          <p className="text-xs text-slate-400">
            Operations & Subsidy Command for Bhubaneswar & Cuttack Mobility
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-2 py-2 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-orange-400 border border-orange-500/30 text-xs font-bold shadow transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Financial CSV</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-800 scrollbar-none">
        <button
          type="button"
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Operations & Financial Ledger
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('drivers')}
          className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'drivers'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>Driver Approvals</span>
          {pendingDrivers > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold">
              {pendingDrivers}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fleet')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'fleet'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Fleet & Owner's 3 Vehicles
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fares')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'fares'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          50% Subsidy & Fare Rates
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('liveMap')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'liveMap'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Live GPS Fleet Map
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('support')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'support'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Complaints ({supportTickets.length})
        </button>
      </div>

      {/* Tab Content 1: Overview & Financial Ledger */}
      {activeTab === 'overview' && (
        <div className="flex flex-col gap-6">
          {/* Key Metric Tiles */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">
                Total Bookings
              </span>
              <p className="text-2xl font-black text-white font-mono mt-1">
                {totalBookings}
              </p>
              <span className="text-[10px] text-emerald-400 font-semibold block mt-0.5">
                {completedRides.length} Completed · {cancelledRides.length} Cancelled
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">
                Active Drivers
              </span>
              <p className="text-2xl font-black text-white font-mono mt-1">
                {onlineDrivers} <span className="text-xs font-normal text-slate-400">/ {totalDrivers}</span>
              </p>
              <span className="text-[10px] text-emerald-400 font-semibold block mt-0.5">
                {approvedDrivers} Approved Captains
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-500/15 to-slate-900 border border-orange-500/30 shadow-lg">
              <span className="text-[11px] font-bold text-orange-400 uppercase tracking-wide">
                Customer Payments
              </span>
              <p className="text-2xl font-black text-white font-mono mt-1">
                ₹{totalCustomerCollections}
              </p>
              <span className="text-[10px] text-orange-300 font-medium block mt-0.5">
                Collected from Riders (50%)
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/15 to-slate-900 border border-emerald-500/30 shadow-lg">
              <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wide">
                50% Subsidy Disbursed
              </span>
              <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                ₹{totalSubsidyDisbursed}
              </p>
              <span className="text-[10px] text-emerald-300/80 font-medium block mt-0.5">
                Govt & Company Subsidy
              </span>
            </div>
          </div>

          {/* Deep Financial Ledger & Owner Fleet Accounting */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Ledger Card */}
            <div className="lg:col-span-7 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-orange-400" />
                  Consolidated Financial Ledger
                </h3>
                <span className="text-[10px] font-mono text-slate-400">
                  Six-Month Active Phase
                </span>
              </div>

              <div className="flex flex-col gap-2.5 text-xs">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">Total Gross Value of Rides (100%):</span>
                  <span className="font-mono font-bold text-white text-sm">₹{totalGrossRevenue}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">Direct Customer Collections (50%):</span>
                  <span className="font-mono font-bold text-orange-400">₹{totalCustomerCollections}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">Company & Govt 50% Subsidy Outlay:</span>
                  <span className="font-mono font-bold text-emerald-400">₹{totalSubsidyDisbursed}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">External Captain Payouts (Friends & Ind.):</span>
                  <span className="font-mono font-bold text-rose-400">₹{externalDriverPayouts}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-orange-500/10 border border-orange-500/30">
                  <div>
                    <span className="font-bold text-white block">
                      Owner's 3 Vehicles Revenue Retained:
                    </span>
                    <span className="text-[10px] text-orange-300">
                      Not paid as external payout; retained in company equity
                    </span>
                  </div>
                  <span className="font-mono font-extrabold text-orange-400 text-sm">
                    ₹{ownerVehiclesRevenueRetained}
                  </span>
                </div>
              </div>
            </div>

            {/* Right Payment Channels & Vehicles breakdown */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              {/* Payment Methods Breakdown */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col gap-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide">
                  Payment Channels Utilized
                </h4>
                <div className="flex flex-col gap-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-slate-300">UPI QR Code (Company VPA)</span>
                    <span className="font-mono font-bold text-orange-400">{upiPayments} Rides</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-slate-300">Online Gateway (Cards/NetBanking)</span>
                    <span className="font-mono font-bold text-orange-400">{onlinePayments} Rides</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-slate-300">Cash Collected by Driver</span>
                    <span className="font-mono font-bold text-orange-400">{cashPayments} Rides</span>
                  </div>
                </div>
              </div>

              {/* Fleet Ownership Overview */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col gap-2 text-xs">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide">
                  Fleet Breakdown ({totalDrivers} Total)
                </h4>
                <div className="flex justify-between py-1.5 border-b border-slate-800 text-slate-400">
                  <span>Company Owner's 3 Vehicles:</span>
                  <span className="text-white font-mono font-bold">{ownerVehiclesCount}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-800 text-slate-400">
                  <span>Friends' Vehicles:</span>
                  <span className="text-white font-mono font-bold">{friendVehiclesCount}</span>
                </div>
                <div className="flex justify-between py-1.5 text-slate-400">
                  <span>Independent Partner Drivers:</span>
                  <span className="text-white font-mono font-bold">{independentVehiclesCount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content 2: Driver Approvals */}
      {activeTab === 'drivers' && <DriverApprovals drivers={drivers} language={appState.language} />}

      {/* Tab Content 3: Fleet & Ownership Table */}
      {activeTab === 'fleet' && <FleetOwnershipTable drivers={drivers} rides={rideHistory} language={appState.language} />}

      {/* Tab Content 4: Fares & Subsidy */}
      {activeTab === 'fares' && (
        <FareSubsidyManager
          fareConfig={fareConfig}
          subsidyConfig={subsidyConfig}
          language={appState.language}
        />
      )}

      {/* Tab Content 5: Live GPS Fleet Map */}
      {activeTab === 'liveMap' && (
        <div className="flex flex-col gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-1">
              Live Fleet Map · Bhubaneswar & Cuttack
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              Monitoring all {onlineDrivers} active online captains across Twin City service geofences.
            </p>
            <MapDisplay
              nearbyDrivers={drivers}
              className="h-[460px] w-full"
            />
          </div>
        </div>
      )}

      {/* Tab Content 6: Complaints & Support Tickets */}
      {activeTab === 'support' && (
        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-bold text-white">Support & Safety Incidents</h3>
          {supportTickets.length === 0 ? (
            <p className="text-xs text-slate-500 italic">No open complaints.</p>
          ) : (
            supportTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs flex flex-col gap-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{ticket.subject}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      ticket.status === 'resolved'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {ticket.status}
                  </span>
                </div>
                <p className="text-slate-300">{ticket.message}</p>
                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-500">
                  <span>From: {ticket.userName} ({ticket.userType})</span>
                  {ticket.status !== 'resolved' && (
                    <button
                      type="button"
                      onClick={() => store.resolveSupportTicket(ticket.id)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs"
                    >
                      Mark Resolved
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
