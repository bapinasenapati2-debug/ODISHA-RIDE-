import React, { useState } from 'react';
import { FareConfig, SubsidyConfig, Language } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import { Sparkles, DollarSign, Clock, Save, CheckCircle2, ShieldCheck, Bike, Car } from 'lucide-react';

interface FareSubsidyManagerProps {
  fareConfig: FareConfig;
  subsidyConfig: SubsidyConfig;
  language: Language;
}

export const FareSubsidyManager: React.FC<FareSubsidyManagerProps> = ({
  fareConfig,
  subsidyConfig,
  language
}) => {
  const t = getTranslation(language);

  // Subsidy state
  const [isActive, setIsActive] = useState(subsidyConfig.isActive);
  const [percentage, setPercentage] = useState(subsidyConfig.percentage);

  // Bike fare state
  const [bikeBase, setBikeBase] = useState(fareConfig.bike?.baseFare || 20);
  const [bikePerKm, setBikePerKm] = useState(fareConfig.bike?.perKmRate || 9);
  const [bikeMin, setBikeMin] = useState(fareConfig.bike?.minFare || 20);
  const [bikePlatformFee, setBikePlatformFee] = useState(fareConfig.bike?.platformFee || 5);

  // Auto fare state
  const [autoBase, setAutoBase] = useState(fareConfig.auto.baseFare);
  const [autoPerKm, setAutoPerKm] = useState(fareConfig.auto.perKmRate);
  const [autoMin, setAutoMin] = useState(fareConfig.auto.minFare);
  const [autoPlatformFee, setAutoPlatformFee] = useState(fareConfig.auto.platformFee || 7);

  // Cab fare state
  const [cabBase, setCabBase] = useState(fareConfig.cab.baseFare);
  const [cabPerKm, setCabPerKm] = useState(fareConfig.cab.perKmRate);
  const [cabMin, setCabMin] = useState(fareConfig.cab.minFare);
  const [cabPlatformFee, setCabPlatformFee] = useState(fareConfig.cab.platformFee || 10);

  const [savedNotice, setSavedNotice] = useState(false);

  // Calculate 6-month validity countdown
  const launchDate = new Date(subsidyConfig.launchDate);
  const expiryDate = new Date(subsidyConfig.validUntil);
  const today = new Date();
  const diffTime = expiryDate.getTime() - today.getTime();
  const daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    store.updateSubsidyConfig({
      ...subsidyConfig,
      isActive,
      percentage
    });

    store.updateFareConfig({
      bike: {
        baseFare: Number(bikeBase),
        perKmRate: Number(bikePerKm),
        minFare: Number(bikeMin),
        platformFee: Number(bikePlatformFee)
      },
      auto: {
        baseFare: Number(autoBase),
        perKmRate: Number(autoPerKm),
        minFare: Number(autoMin),
        platformFee: Number(autoPlatformFee)
      },
      cab: {
        baseFare: Number(cabBase),
        perKmRate: Number(cabPerKm),
        minFare: Number(cabMin),
        platformFee: Number(cabPlatformFee)
      }
    });

    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <form onSubmit={handleSave} className="flex flex-col gap-5">
      {/* 50% Subsidy Controller Box */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-orange-500/10 via-amber-500/5 to-slate-900 border border-orange-500/30 backdrop-blur-md shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500 text-white shadow-md">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Six-Month 50% Odisha Customer Subsidy Engine
              </h3>
              <p className="text-[11px] text-slate-400">
                Core Business Incentive: Rider pays 50%, Odisha Ride covers 50%, Captain gets 100%
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-300">Subsidy Active:</span>
            <button
              type="button"
              onClick={() => setIsActive(!isActive)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isActive ? 'bg-emerald-600' : 'bg-slate-800'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isActive ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* 6-Month Countdown & Dates */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase font-bold">Official Launch Date</span>
            <span className="font-mono text-xs font-semibold text-white">{subsidyConfig.launchDate}</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase font-bold">6-Month Expiry Date</span>
            <span className="font-mono text-xs font-semibold text-white">{subsidyConfig.validUntil}</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase font-bold">Remaining Days in Phase 1</span>
            <span className="font-mono text-xs font-bold text-emerald-400">{daysRemaining} Days</span>
          </div>
        </div>

        {/* Percentage Slider */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300">Subsidy Percentage Applied</span>
            <span className="font-mono text-lg font-black text-orange-400">{percentage}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            value={percentage}
            onChange={(e) => setPercentage(Number(e.target.value))}
            className="accent-orange-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>0% (No Subsidy)</span>
            <span>50% (Standard Business Rule)</span>
            <span>100% (Free Ride Promo)</span>
          </div>
        </div>
      </div>

      {/* Fare Rate Configuration (Bike, Auto & Cab) */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <h3 className="text-sm font-bold text-white mb-3">
          Fare Rate & Platform Fee Manager (Bhubaneswar & Cuttack Geofence)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Bike Taxi Fares */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-emerald-400 uppercase flex items-center gap-1.5">
                <Bike className="w-3.5 h-3.5" />
                Bike Taxi (2-Wheeler)
              </span>
              <span className="text-[10px] text-slate-400">1 Rider</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Base Fare (First 1.5 km)</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={bikeBase}
                  onChange={(e) => setBikeBase(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Per-Kilometer Rate</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={bikePerKm}
                  onChange={(e) => setBikePerKm(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Platform Fee</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={bikePlatformFee}
                  onChange={(e) => setBikePlatformFee(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Auto Rickshaw Fares */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-amber-400 uppercase">
                Auto Rickshaw (3-Wheeler)
              </span>
              <span className="text-[10px] text-slate-400">3 Seats</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Base Fare (First 1.5 km)</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={autoBase}
                  onChange={(e) => setAutoBase(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Per-Kilometer Rate</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={autoPerKm}
                  onChange={(e) => setAutoPerKm(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Platform Fee</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={autoPlatformFee}
                  onChange={(e) => setAutoPlatformFee(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Cab / Taxi Fares */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-orange-400 uppercase flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5" />
                Cab / Taxi (4-Wheeler)
              </span>
              <span className="text-[10px] text-slate-400">4 Seats AC</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Base Fare (First 2.0 km)</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={cabBase}
                  onChange={(e) => setCabBase(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Per-Kilometer Rate</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={cabPerKm}
                  onChange={(e) => setCabPerKm(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Platform Fee</label>
              <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-2">
                <span className="text-xs text-orange-400 font-bold mr-1">₹</span>
                <input
                  type="number"
                  value={cabPlatformFee}
                  onChange={(e) => setCabPlatformFee(Number(e.target.value))}
                  className="bg-transparent text-xs text-white font-mono w-full focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="mt-4 flex items-center justify-between pt-3 border-t border-slate-800">
          {savedNotice ? (
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              Fare rates and subsidy configuration saved successfully!
            </span>
          ) : (
            <span className="text-[11px] text-slate-500">
              * Updates apply immediately to all new Bhubaneswar & Cuttack booking calculations.
            </span>
          )}

          <button
            type="submit"
            className="py-2.5 px-5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Configuration</span>
          </button>
        </div>
      </div>
    </form>
  );
};
