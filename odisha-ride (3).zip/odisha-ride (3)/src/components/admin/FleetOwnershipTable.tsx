import React, { useState } from 'react';
import { DriverUser, RideBooking, VehicleOwnership, Language } from '../../types';
import { Car, ShieldCheck, DollarSign, Award, Users } from 'lucide-react';

interface FleetOwnershipTableProps {
  drivers: DriverUser[];
  rides: RideBooking[];
  language: Language;
}

export const FleetOwnershipTable: React.FC<FleetOwnershipTableProps> = ({
  drivers,
  rides
}) => {
  const [selectedCategory, setSelectedCategory] = useState<VehicleOwnership | 'all'>('all');

  const filteredDrivers = drivers.filter((d) => {
    if (selectedCategory === 'all') return true;
    return d.vehicleOwnership === selectedCategory;
  });

  // Calculate statistics per ownership category
  const getCategoryStats = (ownership: VehicleOwnership) => {
    const categoryDrivers = drivers.filter((d) => d.vehicleOwnership === ownership);
    const categoryRides = rides.filter(
      (r) => r.vehicleOwnership === ownership && r.status === 'completed'
    );
    const grossBookings = categoryRides.reduce((sum, r) => sum + r.totalGrossFare, 0);
    const customerCollections = categoryRides.reduce((sum, r) => sum + r.customerPayableFare, 0);
    const subsidyExpense = categoryRides.reduce((sum, r) => sum + r.companySubsidyAmount, 0);
    
    // For owner_company vehicles, the fare is retained company earnings (not paid out to external third party)
    const externalPayouts = ownership === 'owner_company' ? 0 : grossBookings;
    const companyRetained = ownership === 'owner_company' ? grossBookings : 0;

    return {
      driverCount: categoryDrivers.length,
      tripCount: categoryRides.length,
      grossBookings,
      customerCollections,
      subsidyExpense,
      externalPayouts,
      companyRetained
    };
  };

  const ownerStats = getCategoryStats('owner_company');
  const friendStats = getCategoryStats('friend');
  const indStats = getCategoryStats('independent');

  return (
    <div className="flex flex-col gap-4">
      {/* 3 Ownership Classification Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Owner's Own 3 Vehicles Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-600/20 to-amber-900/30 border border-orange-500/40 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-orange-400 uppercase tracking-wide flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              Owner's Own 3 Vehicles
            </span>
            <span className="px-2 py-0.5 rounded bg-orange-500 text-white font-mono text-[10px] font-bold">
              Company Fleet
            </span>
          </div>
          <p className="text-2xl font-black text-white font-mono">
            {ownerStats.driverCount} <span className="text-xs font-normal text-slate-400">Vehicles</span>
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-col gap-1 text-[11px]">
            <div className="flex justify-between text-slate-400">
              <span>Completed Trips:</span>
              <span className="text-white font-mono">{ownerStats.tripCount}</span>
            </div>
            <div className="flex justify-between text-emerald-400 font-semibold">
              <span>Retained Company Revenue:</span>
              <span className="font-mono">₹{ownerStats.companyRetained}</span>
            </div>
            <p className="text-[10px] text-orange-300/80 italic mt-0.5">
              * Fares from owner vehicles stay in company accounts (no external driver commission payout).
            </p>
          </div>
        </div>

        {/* Friends' Vehicles Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-600/20 to-blue-900/30 border border-sky-500/40 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-sky-400 uppercase tracking-wide flex items-center gap-1.5">
              <Users className="w-4 h-4" />
              Friends' Vehicles
            </span>
            <span className="px-2 py-0.5 rounded bg-sky-600 text-white font-mono text-[10px] font-bold">
              Affiliated
            </span>
          </div>
          <p className="text-2xl font-black text-white font-mono">
            {friendStats.driverCount} <span className="text-xs font-normal text-slate-400">Vehicles</span>
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-col gap-1 text-[11px]">
            <div className="flex justify-between text-slate-400">
              <span>Completed Trips:</span>
              <span className="text-white font-mono">{friendStats.tripCount}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Partner Payouts:</span>
              <span className="text-orange-400 font-mono font-bold">₹{friendStats.externalPayouts}</span>
            </div>
            <p className="text-[10px] text-sky-300/80 italic mt-0.5">
              * Driver receives 100% fare including the 50% company subsidy.
            </p>
          </div>
        </div>

        {/* Independent Partner Drivers Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-600/20 to-indigo-900/30 border border-purple-500/40 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-purple-400 uppercase tracking-wide flex items-center gap-1.5">
              <Car className="w-4 h-4" />
              Independent Drivers
            </span>
            <span className="px-2 py-0.5 rounded bg-purple-600 text-white font-mono text-[10px] font-bold">
              Open Network
            </span>
          </div>
          <p className="text-2xl font-black text-white font-mono">
            {indStats.driverCount} <span className="text-xs font-normal text-slate-400">Captains</span>
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-col gap-1 text-[11px]">
            <div className="flex justify-between text-slate-400">
              <span>Completed Trips:</span>
              <span className="text-white font-mono">{indStats.tripCount}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Independent Payouts:</span>
              <span className="text-orange-400 font-mono font-bold">₹{indStats.externalPayouts}</span>
            </div>
            <p className="text-[10px] text-purple-300/80 italic mt-0.5">
              * Registered third-party auto rickshaw & cab captains across Odisha.
            </p>
          </div>
        </div>
      </div>

      {/* Filter Selector */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-slate-400">Filter by Ownership:</span>
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['all', 'owner_company', 'friend', 'independent'] as const).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setSelectedCategory(key)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                selectedCategory === key
                  ? 'bg-orange-500 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {key === 'all'
                ? 'All Vehicles'
                : key === 'owner_company'
                ? "Owner's 3 Fleet"
                : key === 'friend'
                ? "Friends' Fleet"
                : 'Independent'}
            </button>
          ))}
        </div>
      </div>

      {/* Detailed Fleet Ledger Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="border-b border-slate-800 bg-slate-950/70 text-[11px] uppercase font-bold text-slate-400">
            <tr>
              <th className="p-3.5">Vehicle Plate</th>
              <th className="p-3.5">Category & Model</th>
              <th className="p-3.5">Assigned Captain</th>
              <th className="p-3.5">Ownership Classification</th>
              <th className="p-3.5">Completed Rides</th>
              <th className="p-3.5">Financial Accounting</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filteredDrivers.map((driver) => {
              const dRides = rides.filter(
                (r) => r.driverId === driver.id && r.status === 'completed'
              );
              const totalGross = dRides.reduce((s, r) => s + r.totalGrossFare, 0);
              const isOwner = driver.vehicleOwnership === 'owner_company';

              return (
                <tr key={driver.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5 font-mono font-bold text-orange-400 uppercase">
                    {driver.vehicleNumber}
                  </td>
                  <td className="p-3.5">
                    <span className="font-semibold text-white block">{driver.vehicleModel}</span>
                    <span className="text-[10px] text-slate-400">
                      {driver.vehicleCategory === 'auto' ? 'Three Wheeler Auto' : 'Four Wheeler Cab'}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <span className="font-medium text-slate-200 block">{driver.name}</span>
                    <span className="text-[10px] font-mono text-slate-400">+91 {driver.phone}</span>
                  </td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        isOwner
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                          : driver.vehicleOwnership === 'friend'
                          ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                          : 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                      }`}
                    >
                      {isOwner
                        ? "Owner's Own Vehicle"
                        : driver.vehicleOwnership === 'friend'
                        ? "Friend's Vehicle"
                        : 'Independent'}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono font-semibold text-slate-200">
                    {driver.totalTrips} Trips
                  </td>
                  <td className="p-3.5">
                    <div className="flex flex-col">
                      <span className="font-mono font-bold text-white">
                        Gross: ₹{totalGross}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {isOwner ? 'Retained in Company Revenue' : 'Paid out to Captain Bank'}
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
