import React, { useState } from 'react';
import { DriverUser, Language } from '../../types';
import { store } from '../../services/store';
import { getTranslation } from '../../services/i18n';
import { ShieldCheck, ShieldAlert, Check, X, FileText, ExternalLink, User } from 'lucide-react';

interface DriverApprovalsProps {
  drivers: DriverUser[];
  language: Language;
}

export const DriverApprovals: React.FC<DriverApprovalsProps> = ({ drivers, language }) => {
  const t = getTranslation(language);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('Incomplete DL or Insurance verification');

  const filteredDrivers = drivers.filter((d) => {
    if (filter === 'all') return true;
    return d.approvalStatus === filter;
  });

  const handleApprove = (driverId: string) => {
    store.adminApproveDriver(driverId);
  };

  const handleReject = (driverId: string) => {
    store.adminRejectDriver(driverId, rejectReason);
    setRejectingId(null);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Top Filter Bar */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setFilter(status)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors capitalize ${
                filter === status
                  ? 'bg-orange-500 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {status} ({drivers.filter((d) => (status === 'all' ? true : d.approvalStatus === status)).length})
            </button>
          ))}
        </div>
      </div>

      {/* Driver Document Verification Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="border-b border-slate-800 bg-slate-950/70 text-[11px] uppercase font-bold text-slate-400">
            <tr>
              <th className="p-3.5">Captain & Phone</th>
              <th className="p-3.5">Vehicle & Ownership</th>
              <th className="p-3.5">DL / RC / Insurance</th>
              <th className="p-3.5">Payout VPA</th>
              <th className="p-3.5">Verification Status</th>
              <th className="p-3.5 text-right">Admin Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filteredDrivers.map((driver) => (
              <tr key={driver.id} className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3.5">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={driver.photoUrl}
                      alt={driver.name}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <span className="font-bold text-white block">{driver.name}</span>
                      <span className="text-[11px] text-slate-400 font-mono">+91 {driver.phone}</span>
                    </div>
                  </div>
                </td>

                <td className="p-3.5">
                  <div className="flex flex-col">
                    <span className="font-bold text-orange-400 font-mono uppercase">
                      {driver.vehicleNumber}
                    </span>
                    <span className="text-slate-300">{driver.vehicleModel}</span>
                    <span className="text-[10px] text-slate-500 mt-0.5">
                      {driver.vehicleOwnership === 'owner_company'
                        ? "★ Company Owner's Vehicle"
                        : driver.vehicleOwnership === 'friend'
                        ? "Friend's Vehicle"
                        : 'Independent Partner'}
                    </span>
                  </div>
                </td>

                <td className="p-3.5">
                  <div className="flex flex-col gap-0.5 font-mono text-[11px]">
                    <span className="text-slate-300">DL: {driver.drivingLicenseNo}</span>
                    <span className="text-slate-400">RC: {driver.rcNumber}</span>
                    <span className="text-slate-500">INS: {driver.insurancePolicyNo}</span>
                  </div>
                </td>

                <td className="p-3.5 font-mono text-[11px]">
                  <span className="text-slate-200 block">{driver.upiId}</span>
                  <span className="text-slate-500 text-[10px]">{driver.bankAccountNo}</span>
                </td>

                <td className="p-3.5">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase inline-flex items-center gap-1 ${
                      driver.approvalStatus === 'approved'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : driver.approvalStatus === 'pending'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {driver.approvalStatus === 'approved' ? (
                      <ShieldCheck className="w-3 h-3" />
                    ) : (
                      <ShieldAlert className="w-3 h-3" />
                    )}
                    <span>{driver.approvalStatus}</span>
                  </span>
                </td>

                <td className="p-3.5 text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    {driver.approvalStatus !== 'approved' && (
                      <button
                        type="button"
                        onClick={() => handleApprove(driver.id)}
                        className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1 shadow transition-colors"
                        title="Approve Driver Documents"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Approve</span>
                      </button>
                    )}

                    {driver.approvalStatus !== 'rejected' && (
                      <button
                        type="button"
                        onClick={() => setRejectingId(driver.id)}
                        className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 font-semibold text-xs flex items-center gap-1 transition-colors"
                        title="Reject Driver"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Reject</span>
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Rejection Modal */}
      {rejectingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
            <h3 className="text-sm font-bold text-white mb-2">Reject Driver Application</h3>
            <p className="text-xs text-slate-400 mb-3">
              Specify reason for document rejection:
            </p>
            <input
              type="text"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white mb-4 focus:border-rose-500 focus:outline-none"
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setRejectingId(null)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleReject(rejectingId)}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
