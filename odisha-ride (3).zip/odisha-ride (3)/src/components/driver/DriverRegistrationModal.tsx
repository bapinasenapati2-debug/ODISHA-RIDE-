import React, { useState } from 'react';
import { VehicleCategory, VehicleOwnership } from '../../types';
import { store } from '../../services/store';
import { ShieldCheck, FileCheck, X, Car, Upload } from 'lucide-react';

interface DriverRegistrationModalProps {
  onClose: () => void;
}

export const DriverRegistrationModal: React.FC<DriverRegistrationModalProps> = ({ onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [vehicleCategory, setVehicleCategory] = useState<VehicleCategory>('auto');
  const [vehicleModel, setVehicleModel] = useState('Bajaj RE Auto');
  const [vehicleNumber, setVehicleNumber] = useState('OD-02-XX-');
  const [vehicleOwnership, setVehicleOwnership] = useState<VehicleOwnership>('independent');
  const [ownerName, setOwnerName] = useState('');
  const [dlNumber, setDlNumber] = useState('OD02-2022-');
  const [rcNumber, setRcNumber] = useState('RC-OD02-');
  const [insuranceNumber, setInsuranceNumber] = useState('INS-OD-');
  const [upiId, setUpiId] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [ifsc, setIfsc] = useState('');
  const [city, setCity] = useState<'Bhubaneswar' | 'Cuttack'>('Bhubaneswar');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !vehicleNumber) return;

    store.registerNewDriver({
      name,
      phone,
      photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      vehicleCategory,
      vehicleModel,
      vehicleNumber: vehicleNumber.toUpperCase(),
      vehicleOwnership,
      ownerName: vehicleOwnership === 'owner_company' ? 'Company Owner' : ownerName,
      drivingLicenseNo: dlNumber,
      rcNumber,
      insurancePolicyNo: insuranceNumber,
      documentSubmittedDate: new Date().toISOString().slice(0, 10),
      upiId: upiId || `${phone}@upi`,
      bankAccountNo: bankAccount || 'SBIN0001928374',
      ifscCode: ifsc || 'SBIN0002087',
      currentCity: city,
      currentLocation:
        city === 'Bhubaneswar'
          ? { lat: 20.2961, lng: 85.8245 }
          : { lat: 20.4625, lng: 85.8828 }
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-slate-100 my-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-500/20 text-orange-400">
              <FileCheck className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Driver Partner Registration</h3>
              <p className="text-[10px] text-slate-400">Join ODISHA RIDE in Bhubaneswar & Cuttack</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3 text-xs max-h-[75vh] overflow-y-auto pr-1">
          {/* Personal Info */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ramesh Kumar Sahu"
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-orange-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Mobile Number</label>
              <input
                type="tel"
                required
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                placeholder="98610XXXXX"
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:border-orange-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Vehicle Category & Model */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Vehicle Category</label>
              <select
                value={vehicleCategory}
                onChange={(e) => {
                  const cat = e.target.value as VehicleCategory;
                  setVehicleCategory(cat);
                  setVehicleModel(
                    cat === 'bike'
                      ? 'Hero Splendor Plus'
                      : cat === 'auto'
                      ? 'Bajaj RE Auto'
                      : 'Maruti Swift Dzire'
                  );
                }}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-orange-500 focus:outline-none"
              >
                <option value="bike">Two Wheeler (Bike Taxi)</option>
                <option value="auto">Three Wheeler (Auto Rickshaw)</option>
                <option value="cab">Four Wheeler (Car / Cab / Taxi)</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Vehicle Model</label>
              <input
                type="text"
                required
                value={vehicleModel}
                onChange={(e) => setVehicleModel(e.target.value)}
                placeholder="e.g. Bajaj RE Compact or Swift Dzire"
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-orange-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Vehicle Plate & Ownership */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Vehicle Number Plate</label>
              <input
                type="text"
                required
                value={vehicleNumber}
                onChange={(e) => setVehicleNumber(e.target.value)}
                placeholder="OD-02-AX-1234"
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-orange-400 font-mono font-bold uppercase focus:border-orange-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Ownership Type</label>
              <select
                value={vehicleOwnership}
                onChange={(e) => setVehicleOwnership(e.target.value as VehicleOwnership)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-orange-500 focus:outline-none"
              >
                <option value="independent">Independent Driver Partner</option>
                <option value="friend">Friend's Vehicle</option>
                <option value="owner_company">Company Owner's Own Vehicle (3 Units)</option>
              </select>
            </div>
          </div>

          {vehicleOwnership === 'friend' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Vehicle Owner's Name (Friend)</label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="Owner's full name"
                className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
              />
            </div>
          )}

          {/* Document Details for Verification */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <span className="font-bold text-slate-200">Mandatory Verification Documents</span>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">Driving Licence No</label>
                <input
                  type="text"
                  required
                  value={dlNumber}
                  onChange={(e) => setDlNumber(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">RC Book Number</label>
                <input
                  type="text"
                  required
                  value={rcNumber}
                  onChange={(e) => setRcNumber(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">Insurance Policy No</label>
                <input
                  type="text"
                  required
                  value={insuranceNumber}
                  onChange={(e) => setInsuranceNumber(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
            </div>
          </div>

          {/* Bank / UPI Payout Details */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <span className="font-bold text-slate-200">Captain Payout Destination</span>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">UPI ID</label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="ramesh@upi"
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">Bank Account No</label>
                <input
                  type="text"
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  placeholder="30192847192"
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">IFSC Code</label>
                <input
                  type="text"
                  value={ifsc}
                  onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                  placeholder="SBIN0002087"
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono text-[11px]"
                />
              </div>
            </div>
          </div>

          {/* Initial Operating City */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1">Primary Base City</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setCity('Bhubaneswar')}
                className={`p-2 rounded-lg border text-xs font-semibold ${
                  city === 'Bhubaneswar'
                    ? 'border-orange-500 bg-orange-500/20 text-white'
                    : 'border-slate-800 bg-slate-950 text-slate-400'
                }`}
              >
                Bhubaneswar
              </button>
              <button
                type="button"
                onClick={() => setCity('Cuttack')}
                className={`p-2 rounded-lg border text-xs font-semibold ${
                  city === 'Cuttack'
                    ? 'border-orange-500 bg-orange-500/20 text-white'
                    : 'border-slate-800 bg-slate-950 text-slate-400'
                }`}
              >
                Cuttack
              </button>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-orange-500/10 border border-orange-500/30 text-[11px] text-orange-300">
            * Once submitted, our Super Admin reviews your Driving Licence, RC and Insurance before activating your account.
          </div>

          <button
            type="submit"
            className="mt-1 w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg shadow-orange-500/25 transition-all"
          >
            Submit Documents for Admin Approval
          </button>
        </form>
      </div>
    </div>
  );
};
