import React, { useState, useEffect } from 'react';
import { AppState, store } from '../../services/store';
import { DriverUser, RideBooking } from '../../types';
import { MapDisplay } from '../common/MapDisplay';
import { DriverEarnings } from './DriverEarnings';
import { DriverRegistrationModal } from './DriverRegistrationModal';
import { getTranslation } from '../../services/i18n';
import {
  Power,
  CarFront,
  Navigation,
  KeyRound,
  CheckCircle2,
  Clock,
  Phone,
  ShieldCheck,
  UserPlus,
  AlertCircle,
  Banknote,
  QrCode,
  DollarSign,
  Car
} from 'lucide-react';

interface DriverAppProps {
  appState: AppState;
}

export const DriverApp: React.FC<DriverAppProps> = ({ appState }) => {
  const t = getTranslation(appState.language);
  const [activeTab, setActiveTab] = useState<'console' | 'earnings'>('console');
  const [showRegModal, setShowRegModal] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [showCashCollectedPrompt, setShowCashCollectedPrompt] = useState(false);

  // Selected driver profile
  const currentDriver =
    appState.drivers.find((d) => d.id === appState.selectedDriverId) || appState.drivers[0];

  const activeRide = appState.activeRide;
  const isAssignedToThisDriver = activeRide?.driverId === currentDriver.id;
  const isPendingForCategory =
    activeRide?.status === 'searching' &&
    activeRide.vehicleCategory === currentDriver.vehicleCategory &&
    currentDriver.isOnline &&
    currentDriver.isApproved;

  const handleToggleOnline = () => {
    store.toggleDriverOnline(currentDriver.id);
  };

  const handleAcceptRide = () => {
    if (!activeRide) return;
    store.driverAcceptBooking(activeRide.id, currentDriver.id);
  };

  const handleMarkArrived = () => {
    if (!activeRide) return;
    store.driverArrivedAtPickup(activeRide.id);
  };

  const handleStartRide = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRide) return;
    const res = store.driverStartRide(activeRide.id, enteredOtp);
    if (!res.success) {
      setOtpError(res.message || 'Invalid OTP');
    } else {
      setOtpError('');
      setEnteredOtp('');
    }
  };

  const handleCompleteRide = () => {
    if (!activeRide) return;
    store.driverCompleteRide(activeRide.id);
    setShowCashCollectedPrompt(true);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)] max-w-5xl mx-auto p-3 sm:p-5 gap-4">
      {/* Top Driver Switcher & Online / Offline Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/95 border border-slate-800 shadow-xl backdrop-blur-md">
        {/* Driver Selector & Category */}
        <div className="flex items-center gap-3">
          <img
            src={currentDriver.photoUrl}
            alt={currentDriver.name}
            referrerPolicy="no-referrer"
            className="w-11 h-11 rounded-xl object-cover border border-slate-700 shadow"
          />
          <div>
            <div className="flex items-center gap-2">
              <select
                value={currentDriver.id}
                onChange={(e) => store.setSelectedDriverId(e.target.value)}
                className="bg-slate-950 text-xs font-bold text-white border border-slate-800 rounded-lg py-1 px-2 focus:outline-none focus:border-orange-500 cursor-pointer"
              >
                {appState.drivers.map((drv) => (
                  <option key={drv.id} value={drv.id}>
                    {drv.name} ({drv.vehicleNumber} - {drv.vehicleCategory === 'auto' ? 'Auto' : 'Cab'})
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[11px] font-mono text-orange-400 font-semibold">
                {currentDriver.vehicleModel}
              </span>
              <span className="text-[10px] text-slate-500">·</span>
              <span className="text-[10px] text-slate-400">
                {currentDriver.vehicleOwnership === 'owner_company'
                  ? "Owner's Own 3-Fleet"
                  : currentDriver.vehicleOwnership === 'friend'
                  ? "Friend's Vehicle"
                  : 'Independent Partner'}
              </span>
            </div>
          </div>
        </div>

        {/* Online Toggle & Register New Button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowRegModal(true)}
            className="flex items-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden sm:inline">Register Driver</span>
          </button>

          {currentDriver.isApproved ? (
            <button
              type="button"
              onClick={handleToggleOnline}
              className={`flex items-center gap-2 py-2 px-4 rounded-xl font-bold text-xs shadow-md transition-all ${
                currentDriver.isOnline
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/30 ring-2 ring-emerald-500/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>{currentDriver.isOnline ? t.onlineStatus : t.offlineStatus}</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{t.pendingApproval}</span>
            </div>
          )}
        </div>
      </div>

      {/* Driver Tabs: Console vs Earnings */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('console')}
          className={`flex items-center gap-1.5 py-2 px-4 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'console'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <CarFront className="w-4 h-4" />
          <span>Captain Driving Console</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('earnings')}
          className={`flex items-center gap-1.5 py-2 px-4 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'earnings'
              ? 'bg-orange-500 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Earnings & Payouts</span>
        </button>
      </div>

      {activeTab === 'console' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          {/* Left Column: Live Map view with route & customer pickup */}
          <div className="lg:col-span-7 flex flex-col gap-3">
            <MapDisplay
              pickup={activeRide?.pickup}
              destination={activeRide?.destination}
              activeDriver={currentDriver}
              nearbyDrivers={appState.drivers}
              className="h-[360px] sm:h-[440px] w-full"
            />
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex items-center justify-between">
              <span>Operating Base: {currentDriver.currentCity}, Odisha</span>
              <span className="font-mono text-orange-400 font-semibold">
                GPS: {currentDriver.currentLocation.lat.toFixed(4)}, {currentDriver.currentLocation.lng.toFixed(4)}
              </span>
            </div>
          </div>

          {/* Right Column: Incoming Ride Ping / Active Ride Handling */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Case 1: Driver is Offline */}
            {!currentDriver.isOnline && (
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 text-center">
                <Power className="mx-auto h-12 w-12 text-slate-600 mb-3" />
                <h3 className="text-sm font-bold text-white mb-1">{t.offlineStatus}</h3>
                <p className="text-xs text-slate-400 mb-4 max-w-xs mx-auto">
                  You are not receiving booking pings from Bhubaneswar & Cuttack customers. Turn online to start earning.
                </p>
                <button
                  type="button"
                  onClick={handleToggleOnline}
                  className="py-2.5 px-6 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow transition-colors"
                >
                  {t.goOnline}
                </button>
              </div>
            )}

            {/* Case 2: Driver is Online, Waiting for Requests */}
            {currentDriver.isOnline && !isPendingForCategory && !isAssignedToThisDriver && (
              <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/90 p-6 text-center">
                <div className="relative mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
                  <div className="absolute inset-0 rounded-full border border-emerald-500 animate-ping opacity-30" />
                  <Navigation className="h-6 w-6" />
                </div>
                <h3 className="text-sm font-bold text-white mb-1">Waiting for Ride Requests...</h3>
                <p className="text-xs text-slate-400 max-w-xs mx-auto mb-3">
                  You are active in {currentDriver.currentCity}. New requests from nearby riders will chime automatically.
                </p>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-[11px] text-slate-300">
                  <Car className="w-3.5 h-3.5 text-orange-400" />
                  <span>Category: {currentDriver.vehicleCategory === 'auto' ? 'Auto Rickshaw' : 'Cab'}</span>
                </div>
              </div>
            )}

            {/* Case 3: Incoming Ride Request Notification with Audio chime */}
            {currentDriver.isOnline && isPendingForCategory && activeRide && (
              <div className="rounded-2xl border-2 border-orange-500 bg-gradient-to-br from-slate-900 to-slate-950 p-5 shadow-2xl ring-4 ring-orange-500/20 animate-pulse">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <span className="text-xs font-black uppercase text-orange-400 tracking-wider">
                    {t.incomingRide}
                  </span>
                  <div className="px-2 py-0.5 rounded bg-orange-500 text-white font-mono text-xs font-bold">
                    30s
                  </div>
                </div>

                {/* Pickup & Drop Points */}
                <div className="flex flex-col gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs mb-3">
                  <div className="flex items-start gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-500 block">Customer Pickup</span>
                      <p className="font-semibold text-white">{activeRide.pickup.name}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 mt-1 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-500 block">Drop-off</span>
                      <p className="font-semibold text-white">{activeRide.destination.name}</p>
                    </div>
                  </div>
                </div>

                {/* Driver Earnings Guarantee Callout */}
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 mb-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-300 block font-semibold uppercase">
                      {t.driverEarningsGross}
                    </span>
                    <span className="text-xl font-black text-white font-mono tabular-nums">
                      ₹{activeRide.driverPayoutAmount}
                    </span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-medium text-right">
                    Full 100% Fare <br />(Subsidy covered by OR)
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      // Reject ride
                    }}
                    className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
                  >
                    {t.rejectRide}
                  </button>

                  <button
                    type="button"
                    onClick={handleAcceptRide}
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-500/30 transition-all transform active:scale-95"
                  >
                    {t.acceptRide}
                  </button>
                </div>
              </div>
            )}

            {/* Case 4: Active Ride in Progress assigned to this driver */}
            {isAssignedToThisDriver && activeRide && (
              <div className="rounded-2xl border border-slate-800 bg-slate-900/95 p-5 shadow-xl flex flex-col gap-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-orange-400">
                    Active Trip · Ref {activeRide.bookingRef}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono font-bold text-slate-300">
                    {activeRide.status.toUpperCase()}
                  </span>
                </div>

                {/* Rider Details */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div>
                    <h4 className="text-xs font-bold text-white">{activeRide.customerName}</h4>
                    <p className="text-[10px] text-slate-400 font-mono">
                      +91 {activeRide.customerPhone.slice(0, 5)}XXXXX (Masked)
                    </p>
                  </div>
                  <a
                    href={`tel:${activeRide.customerPhone}`}
                    className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors"
                    title="Call Customer"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                </div>

                {/* Navigation Status Progression */}
                {activeRide.status === 'driver_assigned' && (
                  <button
                    type="button"
                    onClick={handleMarkArrived}
                    className="w-full py-3 px-4 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-lg transition-all"
                  >
                    {t.markArrived}
                  </button>
                )}

                {activeRide.status === 'driver_arrived' && (
                  <form onSubmit={handleStartRide} className="flex flex-col gap-2 p-3 rounded-xl bg-slate-950 border border-orange-500/40">
                    <label className="text-xs font-bold text-orange-300">
                      {t.enterRideOtp}
                    </label>
                    <input
                      type="text"
                      maxLength={4}
                      value={enteredOtp}
                      onChange={(e) => setEnteredOtp(e.target.value)}
                      placeholder="e.g. 4-digit PIN"
                      className="p-2.5 text-center font-mono text-xl tracking-widest rounded-lg bg-slate-900 border border-slate-700 text-white focus:border-orange-500 focus:outline-none"
                    />
                    {otpError && (
                      <span className="text-[11px] text-rose-400">{otpError}</span>
                    )}
                    <div className="flex items-center gap-2">
                      <button
                        type="submit"
                        className="flex-1 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition-colors"
                      >
                        {t.startRide}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEnteredOtp(activeRide.startOtp)}
                        className="px-3 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                        title="Auto-fill Customer's code for quick demo"
                      >
                        Fill ({activeRide.startOtp})
                      </button>
                    </div>
                  </form>
                )}

                {activeRide.status === 'in_progress' && (
                  <div className="flex flex-col gap-3">
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex justify-between items-center">
                      <span className="text-slate-400">Trip to: {activeRide.destination.name}</span>
                      <span className="font-mono text-emerald-400 font-bold">{activeRide.distanceKm} km</span>
                    </div>

                    <button
                      type="button"
                      onClick={handleCompleteRide}
                      className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg transition-all"
                    >
                      {t.completeRide}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Earnings Tab */
        <DriverEarnings driver={currentDriver} rides={appState.rideHistory} language={appState.language} />
      )}

      {/* Driver Registration Modal */}
      {showRegModal && (
        <DriverRegistrationModal onClose={() => setShowRegModal(false)} />
      )}

      {/* Cash Collection Confirmation Popup for Driver */}
      {showCashCollectedPrompt && activeRide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-2xl text-center">
            <Banknote className="mx-auto h-12 w-12 text-emerald-400 mb-2" />
            <h3 className="text-sm font-bold text-white mb-1">
              Fare Collection Confirmation
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              If customer is paying cash, collect:
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-2xl font-black text-emerald-400 mb-3">
              ₹{activeRide.customerPayableFare}
            </div>
            <p className="text-[11px] text-slate-400 mb-4">
              * Odisha Ride subsidizes remaining ₹{activeRide.companySubsidyAmount} directly to your bank account. Total payout: ₹{activeRide.driverPayoutAmount}.
            </p>
            <button
              type="button"
              onClick={() => {
                store.payRide(activeRide.id, 'cash');
                setShowCashCollectedPrompt(false);
              }}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow"
            >
              Confirm Cash Received (₹{activeRide.customerPayableFare})
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
