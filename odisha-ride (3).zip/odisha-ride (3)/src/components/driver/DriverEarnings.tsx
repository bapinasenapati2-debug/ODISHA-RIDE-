import React from 'react';
import { DriverUser, RideBooking, Language } from '../../types';
import { getTranslation } from '../../services/i18n';
import { IndianRupee, TrendingUp, CheckCircle, Calendar, ShieldCheck, Wallet } from 'lucide-react';

interface DriverEarningsProps {
  driver: DriverUser;
  rides: RideBooking[];
  language: Language;
}

export const DriverEarnings: React.FC<DriverEarningsProps> = ({
  driver,
  rides,
  language
}) => {
  const t = getTranslation(language);

  const driverRides = rides.filter(
    (r) => r.driverId === driver.id && r.status === 'completed'
  );

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayRides = driverRides.filter((r) => r.createdAt.startsWith(todayStr));

  const totalGrossEarnings = driverRides.reduce((sum, r) => sum + r.driverPayoutAmount, 0);
  const todayEarnings = todayRides.reduce((sum, r) => sum + r.driverPayoutAmount, 0);

  // In Odisha Ride, the driver gets the full 100% fare!
  // E.g., Customer paid 50%, Company paid 50% subsidy, driver receives 100%!
  const totalSubsidyCredits = driverRides.reduce((sum, r) => sum + r.companySubsidyAmount, 0);
  const totalCustomerCollections = driverRides.reduce((sum, r) => sum + r.customerPayableFare, 0);

  return (
    <div className="flex flex-col gap-4">
      {/* Earnings Overview Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-600/20 to-teal-900/30 border border-emerald-500/30 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wide">
              Today's Earnings
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-black text-white font-mono tabular-nums">
            ₹{todayEarnings}
          </span>
          <span className="text-[10px] text-emerald-400/80 block mt-1">
            {todayRides.length} Trips completed today
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-600/20 to-amber-900/30 border border-orange-500/30 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-orange-300 uppercase tracking-wide">
              Total Gross Payout
            </span>
            <div className="p-1.5 rounded-lg bg-orange-500/20 text-orange-400">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-black text-white font-mono tabular-nums">
            ₹{totalGrossEarnings}
          </span>
          <span className="text-[10px] text-orange-300/80 block mt-1">
            {driverRides.length} Lifetime completed trips
          </span>
        </div>
      </div>

      {/* Subsidy Benefit Breakdown for Captain */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs">
        <h4 className="font-bold text-white mb-2 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Full 100% Fare Guarantee with Odisha Ride Subsidy
        </h4>
        <p className="text-slate-400 text-[11px] leading-relaxed mb-3">
          Even though riders receive a 50% discount in Bhubaneswar and Cuttack, you are guaranteed the 100% full approved fare. Odisha Ride company subsidizes the remaining 50% directly into your payout account.
        </p>
        <div className="flex flex-col gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono">
          <div className="flex justify-between text-slate-400">
            <span>Direct Customer Cash / UPI:</span>
            <span className="text-slate-200">₹{totalCustomerCollections} (50%)</span>
          </div>
          <div className="flex justify-between text-emerald-400">
            <span>Company 50% Subsidy Credited:</span>
            <span>+₹{totalSubsidyCredits} (50%)</span>
          </div>
          <div className="flex justify-between font-bold text-white pt-2 border-t border-slate-800">
            <span>Total Captain Payout:</span>
            <span className="text-orange-400 text-sm">₹{totalGrossEarnings} (100%)</span>
          </div>
        </div>
      </div>

      {/* Payout & Bank Account Info */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs">
        <span className="text-slate-400 text-[11px] block mb-1">Configured Payout Destination</span>
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
          <div>
            <p className="font-bold text-white">{driver.upiId || 'driver@upi'}</p>
            <p className="text-[10px] text-slate-500 font-mono">
              Bank A/C: {driver.bankAccountNo} · IFSC: {driver.ifscCode}
            </p>
          </div>
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-semibold">
            Verified
          </span>
        </div>
      </div>

      {/* Recent Trips Log */}
      <div className="flex flex-col gap-2">
        <h4 className="text-xs font-bold text-slate-300 px-1">Completed Trips Log</h4>
        {driverRides.length === 0 ? (
          <p className="text-xs text-slate-500 italic p-3">No completed trips yet.</p>
        ) : (
          driverRides.map((ride) => (
            <div
              key={ride.id}
              className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div>
                <p className="font-semibold text-white">
                  {ride.pickup.name.split('(')[0]} → {ride.destination.name.split('(')[0]}
                </p>
                <p className="text-[10px] text-slate-500">
                  {ride.distanceKm} km · {new Date(ride.createdAt).toLocaleDateString()} · Ref: {ride.bookingRef}
                </p>
              </div>
              <div className="text-right">
                <span className="font-bold text-emerald-400 font-mono text-sm block">
                  +₹{ride.driverPayoutAmount}
                </span>
                <span className="text-[9px] uppercase font-bold text-slate-400">
                  {ride.paymentMethod}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
